#!/bin/bash

IFS=,

# 
# Reloads all execution groups
# 
# Neoflex, 2011
#

. ./config.sh

for i in $bar_list
do

    eg_ref=bar_${i}_execGroup
    
    mqsireload ${brk_ref} -e ${!eg_ref}

done