#!/bin/bash

### Temporary script don't work

#. ./config.sh

#runmqsc ${qmgr_ref} < ficoWorkflow.mq
#runmqsc ${qmgr_ref} < loggerService.mq
