#!/bin/bash

IFS=,

# 
# Overrides existing bar files properties
# 
# Neoflex, 2013
#

. ./config.sh

for i in $bar_list
do

    bar_ref=bar_${i}_name
    app_ref=bar_${i}_resources
    mqsiapplybaroverride -b ../deploy/${!bar_ref}.bar -k ${!app_ref} -p brokerxml_prod.properties

done
