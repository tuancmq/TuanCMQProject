timeout=600
bar_list=${bar_list}
brk_ref=VPBNODE1
qmgr_ref=VPBQM1

# BAR file specific configuration

## Execution groups
bar_AdpAIAIn_execGroup=${bar.AdpAIAIn.execGroup}
bar_AdpB2BIn_execGroup=${bar.AdpB2BIn.execGroup}
bar_AdpB2BOut_execGroup=${bar.AdpB2BOut.execGroup}
bar_AdpBiDataIn_execGroup=${bar.AdpBiDataIn.execGroup}
bar_AdpCCAppOut_execGroup=${bar.AdpCCAppOut.execGroup}
bar_AdpContactCenterOut_execGroup=${bar.AdpContactCenterOut.execGroup}
bar_AdpCRMIn_execGroup=${bar.AdpCRMIn.execGroup}
bar_AdpCTinIn_execGroup=${bar.AdpCTinIn.execGroup}
bar_AdpDICOIn_execGroup=${bar.AdpDICOIn.execGroup}
bar_AdpDreamOut_execGroup=${bar.AdpDreamOut.execGroup}
bar_AdpEBUtilIn_execGroup=${bar.AdpEBUtilIn.execGroup}
bar_AdpEBUtilOut_execGroup=${bar.AdpEBUtilOut.execGroup}
bar_AdpEVNNPCIn_execGroup=${bar.AdpEVNNPCIn.execGroup}
bar_AdpFECreditIn_execGroup=${bar.AdpFECreditIn.execGroup}
bar_AdpFeeIn_execGroup=${bar.AdpFeeIn.execGroup}
bar_AdpFPTIn_execGroup=${bar.AdpFPTIn.execGroup}
bar_AdpFXFOOut_execGroup=${bar.AdpFXFOOut.execGroup}
bar_AdpHHOut_execGroup=${bar.AdpHHOut.execGroup}
bar_AdpICBIn_execGroup=${bar.AdpICBIn.execGroup}
bar_AdpICBOut_execGroup=${bar.AdpICBOut.execGroup}
bar_AdpJetstarIn_execGroup=${bar.AdpJetstarIn.execGroup}
bar_AdpLOSIn_execGroup=${bar.AdpLOSIn.execGroup}
bar_AdpLOSOut_execGroup=${bar.AdpLOSOut.execGroup}
bar_AdpLOSUPLIn_execGroup=${bar.AdpLOSUPLIn.execGroup}
bar_AdpLoyaltyIn_execGroup=${bar.AdpLoyaltyIn.execGroup}
bar_AdpNapasIn_execGroup=${bar.AdpNapasIn.execGroup}
bar_AdpOCBIn_execGroup=${bar.AdpOCBIn.execGroup}
bar_AdpOCBOut_execGroup=${bar.AdpOCBOut.execGroup}
bar_AdpOnepayIn_execGroup=${bar.AdpOnepayIn.execGroup}
bar_AdpPOCOut_execGroup=${bar.AdpPOCOut.execGroup}
bar_AdpPromotionIn_execGroup=${bar.AdpPromotionIn.execGroup}
bar_AdpSmartSMEOut_execGroup=${bar.AdpSmartSMEOut.execGroup}
bar_AdpSMSGWIn_execGroup=${bar.AdpSMSGWIn.execGroup}
bar_AdpT24In_execGroup=${bar.AdpT24In.execGroup}
bar_AdpTCSIn_execGroup=${bar.AdpTCSIn.execGroup}
bar_AdpTIMOIn_execGroup=${bar.AdpTIMOIn.execGroup}
bar_AdpTSIn_execGroup=${bar.AdpTSIn.execGroup}
bar_AdpUPLOut_execGroup=${bar.AdpUPLOut.execGroup}
bar_AdpVMGIn_execGroup=${bar.AdpVMGIn.execGroup}
bar_AdpVndirectIn_execGroup=${bar.AdpVndirectIn.execGroup}
bar_AdpVnpayIn_execGroup=${bar.AdpVnpayIn.execGroup}
bar_AdpVPDirectIn_execGroup=${bar.AdpVPDirectIn.execGroup}
bar_AdpWay4ATMOut_execGroup=${bar.AdpWay4ATMOut.execGroup}
bar_AdpWay4In_execGroup=${bar.AdpWay4In.execGroup}
bar_AdpWFLIn_execGroup=${bar.AdpWFLIn.execGroup}
bar_AdpWFLOut_execGroup=${bar.AdpWFLOut.execGroup}
bar_SrvAIA_execGroup=${bar.SrvAIA.execGroup}
bar_SrvCards_execGroup=${bar.SrvCards.execGroup}
bar_SrvCustomerLoanSummary_execGroup=${bar.SrvCustomerLoanSummary.execGroup}
bar_SrvEcommerce_execGroup=${bar.SrvEcommerce.execGroup}
bar_SrvFTErrHandling_execGroup=${bar.SrvFTErrHandling.execGroup}
bar_SrvFundTransfer_execGroup=${bar.SrvFundTransfer.execGroup}
bar_SrvGetBeneficiaryInfo_execGroup=${bar.SrvGetBeneficiaryInfo.execGroup}
bar_SrvGetCustomerUPLSummary_execGroup=${bar.SrvGetCustomerUPLSummary.execGroup}
bar_SrvGetProductList_execGroup=${bar.SrvGetProductList.execGroup}
bar_SrvJetstar_execGroup=${bar.SrvJetstar.execGroup}
bar_SrvKHDT_execGroup=${bar.SrvKHDT.execGroup}
bar_SrvLog_execGroup=${bar.SrvLog.execGroup}
bar_SrvCards_execGroup=${bar.SrvCards.execGroup}
bar_SrvMISA_execGroup=${bar.SrvMISA.execGroup}
bar_SrvNotification_execGroup=${bar.SrvNotification.execGroup}
bar_SrvPayErrHandling_execGroup=${bar.SrvPayErrHandling.execGroup}
bar_SrvPayment_execGroup=${bar.SrvPayment.execGroup}
bar_SrvPaymentInstalment_execGroup=${bar.SrvPaymentInstalment.execGroup}
bar_SrvSetCardPin_execGroup=${bar.SrvSetCardPin.execGroup}
bar_SrvTCS_execGroup=${bar.SrvTCS.execGroup}
bar_SrvTimo_execGroup=${bar.SrvTimo.execGroup}
bar_SrvVPBS_execGroup=${bar.SrvVPBS.execGroup}
bar_SrvZaloOut_execGroup=${bar.SrvZaloOut.execGroup}
bar_SrvPaymentPartner_execGroup=${bar.SrvPaymentPartner.execGroup}
bar_SrvVndirect_execGroup=${bar.SrvVndirect.execGroup}	

bar_SCFRestOut_execGroup=${bar.SCFRestOut.execGroup}
bar_MSAIIBRestOut_execGroup=${bar.MSAIIBRestOut.execGroup}
bar_AdpDFIn_execGroup=${bar.AdpDFIn.execGroup}
bar_AdpSSCIn_execGroup=${bar.AdpSSCIn.execGroup}
bar_AdpTVSIIn_execGroup=${bar.AdpTVSIIn.execGroup}
bar_AdpKBSIn_execGroup=${bar.AdpKBSIn.execGroup}

bar_AdpHTCIn_execGroup=${bar.AdpHTCIn.execGroup}
bar_AdpAPECIn_execGroup=${bar.AdpAPECIn.execGroup}
bar_AdpNutifoodIn_execGroup=${bar.AdpNutifoodIn.execGroup}
bar_AdpMeeyLandIn_execGroup=${bar.AdpMeeyLandIn.execGroup}

bar_AdpLACVIETIn_execGroup=${bar.AdpLACVIETIn.execGroup}
bar_Adp9PayIn_execGroup=${bar.Adp9PayIn.execGroup}
bar_AdpAhamoveIn_execGroup=${bar.AdpAhamoveIn.execGroup}

bar_AdpVANNOTIFYIn_execGroup=${bar.AdpVANNOTIFYIn.execGroup}

