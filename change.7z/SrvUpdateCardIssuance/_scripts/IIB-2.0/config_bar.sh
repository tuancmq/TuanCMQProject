#!/bin/bash

IFS=,

# 
# Overrides existing bar files properties
# 
# Neoflex, 2013
#

mqsiapplybaroverride -b ../deploy/*.bar -p brokerxml.properties -r
