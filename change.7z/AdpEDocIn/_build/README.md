﻿# Configuration

## _build/version/build.bat

If you use linux then the same configuration in file build.sh

Set ant home variables

```
SET ANT_HOME=C:\soft\apache-ant-1.10.1
```

Set needed parameters in run ant command (see all available parameters in build.properties)

```
%RUN_ANT% run -DtoolkitHome="C:\Program Files (x86)\IBM\IntegrationToolkit90"
```

## _build/version/build.properties

Set needed parameters. Parameters from ant command line has higher priority

```
brokerHome=C:\Program Files\IBM\MQSI\9.0.0.2
```
### Available parameters

```
IIB instalation directory
brokerHome=C:\Program Files\IBM\MQSI\9.0.0.2 
``` 
IBM Integration Toolkit instalation directory 
toolkitHome=C:\Program Files (x86)\IBM\IntegrationToolkit90
```
IIB profile name (mqsiprofile.cmd for Win and mqsiprofile.sh for *nix)  
profileFName=mqsiprofile.cmd
```
The root directory which contains folders `_build`, `_script`, `_docs` and other IIB modules. It is recomended to copy your working sources to temporary directory, because building process makes current directory as workspace and remove `.metadata` directory.
rootDir=../../
```
Build version. It is recomended to have the same `build.version` as names of the folder under `_build`, `_script` and `_docs`
build.version=IIB-2.0
```
Encoding. It is recommended to use utf-8.
build.encoding=utf-8
```
The list of applications for build 
targetBars=AdpT24In,SrvLog,SrvGetBeneficiaryInfo,AdpDreamOut,AdpSMSGWIn,AdpWay4In
```
Directory of sources, the ant will copy directories from this list to a zip in artefacts 
srcFolders=AdpT24In/**,AdpWay4In/**,CommonUtils/**,SrvLog/**,SrvGetBeneficiaryInfo/**,AdpDreamOut/**,AdpSMSGWIn/**
```
Properties for config result bars (relatively ../_scripts/${build.version}/)
It is use only for target "runFromJenkins"
propertyFile=brokerxml.properties
```
Host, port, queue manager name for deploy to 
It is use only for target "runFromJenkins"
deployHost=10.37.24.121 
deployPort=2514       
deployQM=HA_QM1
brokerName=MQP1BRK
```

## _scripts/version/config.*

Add strings with options for each ptentially configurable bar-file

# Run

## Build

Make sure that root directory of sources contains folders:

* **_build** - scripts for build IIB bar archives from sources

* **_docs** - documentation, which will be copied to the `doc` directory of release package

* **_scripts** - scripts, which will be copied to the `script` directory of release package 

In each of the folder must be created folder with name of the release package (e.g., IIB-2.0). For build configuration see [Configuration](#configuration) chapter. 

To run build process execute next commands:

```bash
> cd  _build\version
> build.bat
```

As a result of script execution the folder `release` will be created in the root directory.

## Bars Configuration

Assembled release package should be configured according to the environment. Configuration parameters located in the folder `release\version\scripts` which was copied from folder `_scripts\version`. You should put standard IIB configuration to the file `brokerxml.properties`. Additional parameters for configuration see in [Configuration](#configuration) chapter. To run configuration proccess execute commands:

```bash
> cd release\version\scripts
> config_bar.bat
```