#!/bin/bash


IFS=,

# 
# Removes all deployed resources from excution groups
# 
# Neoflex, 2013
#

. ./config.sh

for i in $bar_list
do

    eg_ref=bar_${i}_execGroup

    mqsideploy ${brk_ref} -e ${!eg_ref} -w $timeout -d ${i}

done
