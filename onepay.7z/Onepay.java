/**
 * 
 */
package vn.com.vpbank.onepay;

/**
 * @author manhkt
 *
 */
import vn.com.vpbank.onepay.Authorization;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.HashMap;
import java.util.Map;

public class Onepay {

	/**
	 * @param args
	 */
	// String TAG = "SyncDSP";
	static int expires = 300;
	static DateFormat yyyyMMddTHHmmssZ = new SimpleDateFormat(
			"yyyyMMdd\'T\'HHmmss\'Z\'");
	private static final Logger logger = Logger
			.getLogger(Onepay.class.getName());

	// khai bao 1 du lieu
	// String region = "onepay";
	// String baseMtf = "https://dev.onepay.vn";
	// String appId = "VPB";
	// String appKey = "A57525892B2E40A8845E201BF0114BBF";

	public static void main(String[] arg) throws Exception {
		Onepay client = new Onepay();
		// HttpRes httpResponse = client.putNotify();
		// System.out.println("httpResponse:" + httpResponse.toString());
		
		String region = "onepay";
		String APPID = "VPB";
		String APPKEY = "A57525892B2E40A8845E201BF0114BBF";
		String URIHTTP = "/paycollect/api/v1/banks/VPBKVNVX/funds_transfers/";
		String URISIGN = "/paycollect/api/v1/banks/VPBKVNVX/funds_transfers/";
		String payCollect = "{\"request_id\":\"2024061022271527\",\"request_time\":\"2024-06-11 05:27:15\",\"receiver_bank_id\":\"VPBKVNVX\",\"receiver_master_number\":\"231749969\",\"receiver_account_number\":\"06633600995\",\"receiver_holder_name\":\"CONG TY CP FUNDIIN\",\"amount\":\"208000\",\"currency\":\"VND\",\"create_time\":\"20240608\",\"funds_transfer_id\":\"FT24160035367333\",\"remark\":\"NHAN TU 1819088888 TRACE 105203 ND TSC20381321 FT24160460441290\",\"trans_time\":\"2024-06-08 16:21:26\"}";
		String auth = getAuthorization(region,APPID,APPKEY,URIHTTP,URISIGN,payCollect);
		int i = 1;
	}

	public static String getAuthorization(String region, String appId,
			String appKey, String uriHttp, String uriSign, String payCollect) {
		Map<String, Object> signedHeaders = null;	
		Authorization authorization = null;
		String result = "";
		yyyyMMddTHHmmssZ.setTimeZone(TimeZone.getTimeZone("UTC"));
		// String uriHttp =
		// "/paycollect/api/v1/banks/VPBKVNVX/funds_transfers/fund123";
		// String uriSign =
		// "/paycollect/api/v1/banks/VPBKVNVX/funds_transfers/fund123";
		String dt = "";
		try {
			Date dateTime = new Date();
			dt = yyyyMMddTHHmmssZ.format(dateTime);			
			signedHeaders = new HashMap<String, Object>();
			signedHeaders.put("X-OP-Date", dt);
			signedHeaders.put("X-OP-Expires", expires + "");

//			 payCollect =
//			 "{\"sender_bank_id\":\"VPBKVNVX\",\"sender_account_number\":\"123452121\",\"sender_card_number\":\"\",\"sender_holder_name\":\"\",\"amount\":12322,\"currency\":\"VND\",\"receiver_bank_id\":\"1212\",\"receiver_account_number\":\"1231212121\",\"receiver_card_number\":\"\",\"receiver_holder_name\":\"NGUYEN VAN A\",\"funds_transfer_id\":\"123212121\",\"funds_transfer_info\":\"12312121\",\"remark\":\"chuyen tien\",\"state\":\"approved\",\"response_code\":\"00\",\"response_message\":\"successful\",\"create_time\":\"01/11/2020\",\"request_id\":\"1231321\",\"request_time\":\"01/11/2020\"}";
			// System.out.println("payCollect:" + payCollect);
			Map queryParamsMap = new LinkedHashMap();
			authorization = new Authorization(appId, appKey, region,
					"paycollect", "PUT", uriSign, queryParamsMap,
					signedHeaders, payCollect.getBytes(), dateTime, expires);
			// logger.log(Level.INFO, "authorization:" +
			// authorization.toString());
//			signedHeaders.put("Content-Type", "application/json");
//			signedHeaders.put("Accept", "application/json");
			
//			signedHeaders.put("X-OP-Date", dt);
//			signedHeaders.put("X-OP-Expires", expires + "");
//			signedHeaders.put("X-OP-Authorization", authorization.toString());
			
//			System.out.println("signedHeaders:" + signedHeaders);
//			System.out.println("authorization:" + authorization.toString());
// 			System.out.println("authorization:" + authorization.getSignedHeaders());

		} catch (Exception e) {
			e.printStackTrace();
			logger.log(Level.SEVERE, e.toString());

		}
		  result = "X-OP-Date=" + dt + "##Accept=application/json"   
				+ "##X-OP-Expires=" + expires + "##X-OP-Authorization=" + authorization +"##Content-Type=application/json";
		
		return result;
	}
	public static byte[] getBytePayload(String payCollect) { 
		return payCollect.getBytes();
	}
}
