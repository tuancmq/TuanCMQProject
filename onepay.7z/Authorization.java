package vn.com.vpbank.onepay;


import java.security.MessageDigest;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.SortedMap;
import java.util.TimeZone;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class Authorization {
  private static Logger logger = Logger.getLogger(Authorization.class.getName());
  
  public static final String EMPTY_BODY_SHA256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
  
  public static final String UNSIGNED_PAYLOAD = "UNSIGNED-PAYLOAD";
  
  public static final String X_OP_AUTHORIZATION_HEADER = "X-OP-Authorization";
  
  public static final String X_OP_DATE_HEADER = "X-OP-Date";
  
  public static final String X_OP_EXPIRES_HEADER = "X-OP-Expires";
  
  public static final String SCHEME = "OWS1";
  
  public static final String ALGORITHM = "OWS1-HMAC-SHA256";
  
  public static final String TERMINATOR = "ows1_request";
  
  public static final DateFormat yyyyMMdd = new SimpleDateFormat("yyyyMMdd");
  
  public static final DateFormat yyyyMMddTHHmmssZ = new SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'");
  
  public static final DateFormat yyyy_MM_ddTHH_mm_ssZ = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
  
  private String httpMethod;
  
  private String uri;
  
  static {
    yyyyMMdd.setTimeZone(TimeZone.getTimeZone("UTC"));
    yyyyMMddTHHmmssZ.setTimeZone(TimeZone.getTimeZone("UTC"));
    yyyy_MM_ddTHH_mm_ssZ.setTimeZone(TimeZone.getTimeZone("UTC"));
  }
  
  private SortedMap<String, String> queryParameters = new TreeMap<>();
  
  private String algorithm;
  
  private String credential;
  
  private String region;
  
  private String service;
  
  private String terminator;
  
  private SortedMap<String, String> signedHeaders = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
  
  private String signedHeaderNames;
  
  private String signature;
  
  private String accessKeyId;
  
  private String secretAccessKey;
  
  private int expires;
  
  private Date timeStamp;
  
  private byte[] payload;
  
  private Map<String, String> debugInfo = new LinkedHashMap<>();
  
  public Authorization(String accessKeyId, String secretAccessKey, String region, String service, String httpMethod, String uri, Map queryParameters, Map signedHeaders, byte[] payload) throws Exception {
    this(accessKeyId, secretAccessKey, region, service, httpMethod, uri, queryParameters, signedHeaders, payload, 
        
        parse(yyyyMMddTHHmmssZ, ((String)signedHeaders.get("X-OP-Date")).replaceAll("[-:]", "")), 
        Integer.parseInt((String)signedHeaders.get("X-OP-Expires")));
  }
  
  public Authorization(String accessKeyId, String secretAccessKey, String region, String service, String httpMethod, String uri, Map queryParameters, Map signedHeaders, byte[] payload, Date dateTime, int expires) {
    this("OWS1-HMAC-SHA256", accessKeyId, secretAccessKey, region, service, "ows1_request", httpMethod, uri, queryParameters, signedHeaders, payload, dateTime, expires);
  }
  
  public Authorization(String algorithm, String accessKeyId, String secretAccessKey, String region, String service, String terminator, String httpMethod, String uri, Map<? extends String, ? extends String> queryParameters, Map<? extends String, ? extends String> signedHeaders, byte[] payload, Date timeStamp, int expires) {
    this.algorithm = algorithm;
    this.accessKeyId = accessKeyId;
    this.secretAccessKey = secretAccessKey;
    this.timeStamp = timeStamp;
    this.region = region;
    this.service = service;
    this.terminator = terminator;
    this.credential = accessKeyId + "/" + format(yyyyMMdd, timeStamp) + "/" + region + "/" + service + "/" + terminator;
    this.httpMethod = httpMethod;
    this.uri = uri;
    if (queryParameters != null)
      this.queryParameters.putAll(queryParameters); 
    if (signedHeaders != null)
      this.signedHeaders.putAll(signedHeaders); 
    this.payload = payload;
    this.expires = expires;
    sign();
  }
  
  private static final Pattern pAuthorization = Pattern.compile("^([^ ]+) Credential=([^/]+/\\d{8}/[^/]+/[^/]+/[^,]+),SignedHeaders=([-_a-z0-9;]*),Signature=([a-f0-9]{64})$");
  
  private static final Pattern pCredential = Pattern.compile("^([^/]+)/(\\d{8})/([^/]+)/([^/]+)/([^,]+)$");
  
  private static final Pattern pSignedHeaders = Pattern.compile("([^;]+)");
  
  private static final Pattern pSignature = Pattern.compile("^[a-f0-9]{64}$");
  
  public Authorization(String authorizationHeader, String timeStamp, int expires) {
    try {
      this.timeStamp = parse(yyyyMMddTHHmmssZ, timeStamp.replaceAll("[-:]", ""));
      this.expires = expires;
      if (authorizationHeader != null) {
        Matcher mAuthorization = pAuthorization.matcher(authorizationHeader);
        if (mAuthorization.find()) {
          this.algorithm = mAuthorization.group(1);
          this.credential = mAuthorization.group(2);
          Matcher mCredential = pCredential.matcher(this.credential);
          if (mCredential.find()) {
            this.accessKeyId = mCredential.group(1);
            this.region = mCredential.group(3);
            this.service = mCredential.group(4);
            this.terminator = mCredential.group(5);
          } 
          this.signedHeaderNames = mAuthorization.group(3);
          Matcher mHeaders = pSignedHeaders.matcher(this.signedHeaderNames);
          while (mHeaders.find())
            this.signedHeaders.put(mHeaders.group(1), ""); 
          this.signature = mAuthorization.group(4);
        } 
      } 
    } catch (Exception e) {
      logger.log(Level.SEVERE, "", e);
    } 
  }
  
  public Authorization(String algorithm, String credential, String signedHeaderNames, String signature, String timeStamp, int expires) {
    try {
      this.timeStamp = parse(yyyyMMddTHHmmssZ, timeStamp.replaceAll("[-:]", ""));
      this.expires = expires;
      this.algorithm = algorithm;
      if (credential != null && signedHeaderNames != null && signature != null) {
        Matcher mCredential = pCredential.matcher(credential);
        if (mCredential.find()) {
          this.credential = credential;
          this.accessKeyId = mCredential.group(1);
          this.region = mCredential.group(3);
          this.service = mCredential.group(4);
          this.terminator = mCredential.group(5);
        } 
        this.signedHeaderNames = signedHeaderNames;
        Matcher mHeaders = pSignedHeaders.matcher(signedHeaderNames);
        while (mHeaders.find())
          this.signedHeaders.put(mHeaders.group(1), ""); 
        Matcher mSignature = pSignature.matcher(signature);
        if (mSignature.find())
          this.signature = signature; 
      } 
    } catch (Exception e) {
      logger.log(Level.SEVERE, "", e);
    } 
  }
  
  public String getHttpMethod() {
    return this.httpMethod;
  }
  
  public String getUri() {
    return this.uri;
  }
  
  public Map getQueryParameters() {
    return this.queryParameters;
  }
  
  public String getAlgorithm() {
    return this.algorithm;
  }
  
  public String getCredential() {
    return this.credential;
  }
  
  public String getAccessKeyId() {
    return this.accessKeyId;
  }
  
  public String getRegion() {
    return this.region;
  }
  
  public String getService() {
    return this.service;
  }
  
  public String getTerminator() {
    return this.terminator;
  }
  
  public Map<String, String> getSignedHeaders() {
    return this.signedHeaders;
  }
  
  public String getSignature() {
    return this.signature;
  }
  
  public Date getTimeStamp() {
    return this.timeStamp;
  }
  
  public String getTimeStampString() {
    return format(yyyyMMddTHHmmssZ, this.timeStamp);
  }
  
  public int getExpires() {
    return this.expires;
  }
  
  public byte[] getPayload() {
    return this.payload;
  }
  
  public boolean isExpired() {
    return ((System.currentTimeMillis() - this.timeStamp.getTime()) / 1000L > this.expires);
  }
  
  public String toString() {
    return this.algorithm + " Credential=" + this.credential + ",SignedHeaders=" + this.signedHeaderNames + ",Signature=" + this.signature;
  }
  
  public String toQueryString() {
    try {
      return "X-OP-Algorithm=" + this.algorithm + "&X-OP-Credential=" + 
        uriEncode(this.credential, true) + "&X-OP-Date=" + 
        format(yyyyMMddTHHmmssZ, this.timeStamp) + "&X-OP-Expires=" + this.expires + "&X-OP-SignedHeaders=" + 
        
        uriEncode(this.signedHeaderNames, true) + "&X-OP-Signature=" + this.signature;
    } catch (Exception e) {
      logger.log(Level.SEVERE, "", e);
      return null;
    } 
  }
  
  public Map<String, String> getDebugInfo() {
    return this.debugInfo;
  }
  
  private void sign() {
    try {
      String canonicalUri = uriEncode(this.uri, false);
      StringBuilder canonicalQueryString = new StringBuilder();
      for (Map.Entry<String, String> entry : this.queryParameters.entrySet()) {
        if (canonicalQueryString.length() > 0)
          canonicalQueryString.append("&"); 
        canonicalQueryString.append(uriEncode(entry.getKey(), true)).append("=").append(uriEncode(entry.getValue(), true));
      } 
      StringBuilder canonicalHeaders = new StringBuilder();
      StringBuilder buf = new StringBuilder();
      for (Map.Entry<String, String> entry : this.signedHeaders.entrySet()) {
        canonicalHeaders.append(((String)entry.getKey()).toLowerCase()).append(":").append(((String)entry.getValue()).trim()).append("\n");
        if (buf.length() > 0)
          buf.append(";"); 
        buf.append(((String)entry.getKey()).toLowerCase());
      } 
      this.signedHeaderNames = buf.toString();
      String hashedPayload = (this.payload != null) ? ((this.payload.length > 0) ? hex(sha256Hash(this.payload)) : "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855") : "UNSIGNED-PAYLOAD";
      String canonicalRequest = this.httpMethod + "\n" + canonicalUri + "\n" + canonicalQueryString.toString() + "\n" + canonicalHeaders.toString() + "\n" + this.signedHeaderNames + "\n" + hashedPayload;
      String timeStamp = format(yyyyMMddTHHmmssZ, this.timeStamp);
      String scope = format(yyyyMMdd, this.timeStamp) + "/" + this.region + "/" + this.service + "/" + this.terminator;
      String stringToSign = this.algorithm + "\n" + timeStamp + "\n" + scope + "\n" + hex(sha256Hash(canonicalRequest));
      byte[] dateKey = hmacSha256("OWS1" + this.secretAccessKey, format(yyyyMMdd, this.timeStamp));
      byte[] dateRegionKey = hmacSha256(dateKey, this.region);
      byte[] dateRegionServiceKey = hmacSha256(dateRegionKey, this.service);
      byte[] signingKey = hmacSha256(dateRegionServiceKey, this.terminator);
      this.signature = hex(hmacSha256(signingKey, stringToSign));
      this.debugInfo.put("canonicalRequest", canonicalRequest);
      this.debugInfo.put("stringToSign", stringToSign);
      this.debugInfo.put("dateKey", hex(dateKey));
      this.debugInfo.put("dateRegionKey", hex(dateRegionKey));
      this.debugInfo.put("dateRegionServiceKey", hex(dateRegionServiceKey));
      this.debugInfo.put("signingKey", hex(signingKey));
    } catch (Exception e) {
      logger.log(Level.SEVERE, "", e);
    } 
  }
  
  private static String uriEncode(String data, boolean encodeSlash) throws Exception {
    StringBuilder sb = new StringBuilder();
    for (byte ch : data.getBytes("UTF-8")) {
      if ((ch >= 65 && ch <= 90) || (ch >= 97 && ch <= 122) || (ch >= 48 && ch <= 57) || ch == 95 || ch == 45 || ch == 126 || ch == 46 || (ch == 47 && !encodeSlash)) {
        sb.append(Character.toChars(ch));
      } else {
        sb.append("%").append(String.format("%02X", new Object[] { Integer.valueOf(ch & 0xFF) }));
      } 
    } 
    return sb.toString();
  }
  
  private static byte[] hmacSha256(String key, String data) throws Exception {
    return hmacSha256(key.getBytes("UTF-8"), data);
  }
  
  private static byte[] hmacSha256(byte[] key, String data) throws Exception {
    SecretKeySpec signingKey = new SecretKeySpec(key, "HMACSHA256");
    Mac mac = Mac.getInstance("HMACSHA256");
    mac.init(signingKey);
    return mac.doFinal(data.getBytes("UTF-8"));
  }
  
  private static byte[] sha256Hash(String data) throws Exception {
    return sha256Hash(data.getBytes("UTF-8"));
  }
  
  private static byte[] sha256Hash(byte[] data) throws Exception {
    MessageDigest md = MessageDigest.getInstance("SHA-256");
    md.update(data);
    return md.digest();
  }
  
  private static String hex(byte[] data) {
    StringBuilder sb = new StringBuilder();
    for (byte b : data) {
      sb.append(String.format("%02x", new Object[] { Integer.valueOf(b & 0xFF) }));
    } 
    return sb.toString();
  }
  
  private static synchronized Date parse(DateFormat dateFormat, String source) throws ParseException {
    return dateFormat.parse(source);
  }
  
  private static synchronized String format(DateFormat dateFormat, Date date) {
    return dateFormat.format(date);
  }
}
