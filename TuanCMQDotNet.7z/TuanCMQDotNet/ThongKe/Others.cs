﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuanCMQDotNet.ThongKe
{
    internal class Others
    {
    }

    class WhenThenBlock
    {
        public string WhenValue { get; set; }
        public string ThenBlock { get; set; }
    }
}
