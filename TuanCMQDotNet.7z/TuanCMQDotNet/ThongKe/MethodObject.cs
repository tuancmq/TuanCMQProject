﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuanCMQDotNet.ThongKe
{
    internal class MethodObject
    {
        public string MethodName { get; set; }
        public List<FunctionObject> FunctionList;
        

    }
}
