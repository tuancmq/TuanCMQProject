﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuanCMQDotNet.ThongKe
{
    internal class CatalogObject
    {
        public string AppName { get; set; }
        public string BaseURI { get; set; }

        
        public List<MethodObject> MethodList;
    }
}
