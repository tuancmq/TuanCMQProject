﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuanCMQDotNet.ThongKe
{
    internal class FunctionObject
    {
       
        public string FullURI { get; set; }
        public string FunctionURI { get; set; }

        public string FunctionName { get; set; }


        public List<OperationObject> OperationObjects;
        

    }
}
