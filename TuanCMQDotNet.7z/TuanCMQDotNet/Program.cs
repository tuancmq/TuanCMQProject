﻿using TuanCMQDotNet.ThongKe;

namespace TuanCMQDotNet
{
    internal class Program
    {
        static void Main(string[] args)
        {

            ITCASCatalog itcas = new ITCASCatalog();
            itcas.CreateCatalog();
            Console.WriteLine("Hello, World!");
        }
    }
}
