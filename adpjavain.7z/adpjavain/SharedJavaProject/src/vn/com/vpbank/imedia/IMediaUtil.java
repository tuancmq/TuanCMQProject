package vn.com.vpbank.imedia;

import java.security.KeyFactory;
import java.security.PrivateKey; 
import java.security.Signature;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public class IMediaUtil {
	// VPB
	private static String privateKey = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDHS4Id7vs7j2Cg bUrltOCcywpsxoOARoEy+cLRC0yiv3cFyfa16IsdTvVs3nq6z8ZiiPg2VKmgbkcN xSzzQ+ndV6Rps7hqxWlUfN0fCFjnD6KX4XRrzb4RlXbmSNzWp06UJnwU/i6i5tDj x0oaM0bCQL//wEGeifZCmYgT9Nw9ZxvSg4ynfGOjHeUAegJ3DWJoKTLXWdIxSN+Y Yj5hmPJo/MQu1Gho7nkKewpaXYgjqFGyTMUPwLSa3H9i+EkpKbIUyn2aysyxMM1+ WZ9sy53yjpjegV6WLsyBsM56P4BKlqz0roSeYGEiMVFkIkyeXYzy7TOwC/UOBWRs E4GZJ8ANAgMBAAECggEAJSCC9/KaaQkX1ismJc7hfTQyF/uPaek4jneK/IifWT5T /QcX5+GPcQFRpVt4/65PZfHgU7bH9vQ0VnNiIVuIiMyX+30YoQNv0OaGBw72CO2X u7Wri53Dh+ERSmtOgMqgT+cvfHWx2HUpexWYT3M3/l4zpoB5eQB4mQWjHRyjnuhv BYGDuYUZDkPCoFgJtKDUZwu0HngSC5iDRoeUdmrmXqyWZ39nmObqmdYhCFOU/Kay osKahtRCWLD6nPkeB5xJU64RNsRx4zBKdkgYFIMKnrwhgw/6GhxaMhWVbRzU0+N3 FAHz7ZWF0GPXZHy+himtTpjQzPhDiBQ3EYRU1rmF3QKBgQD2HIBeg1xejYgdKZ7A EktvXvBzKG0n4X7wGmbMLgyLmICUm3wVTBcnMmiYsBAKndgeVZTxzU1ojb2h/fR3 sIao/fqZdnUpTfbleFmEdJx0Z4TsIo/SUNw8iUrVCJ1yRNs3LKMezkzvKsOFw6VL qbsBF7YYVNxwBTA1acGoODdS3wKBgQDPTXQ8UJorDM2kW+gHJQYzM33AXyMBAD61 s/prOBHpA7YOZvWgKgTvklEUHeh68FErbTcIbPpu3AGg/IPu+qdV1UyiAwtVmn6V le9dfRlEzm9CnEAcso6WdhYDHdbFGeBiu4FCzkNkFmKU/3330MEWSD878fdV5BS2 yItLXDwWkwKBgGex+JBZ7qhUH76R07Z/vtLtAIi0xtEf3JkTtq5e1KBYoAx9OpnK lpLIVXPH8upWOUIGsxvycaQU3IqNctyfPw2i/Vx9ob3GgLmMrML3UxhkqYfIxCpM MY88FZCO8a+8vVSQ9SW8rIO00+7fUR0BJa6/K9UypDJ6rSZEKflTvlOnAoGAeob9 POknNmrK4WqxKgfoMjstCJcyyVSrvBo02Uq6y082PCz+4Tv0zuVcptdGoeOJFnHn JUPEgeHn1I9sK8RbQ5BfSyMhf+dhCmkkoc1fMhwSBvzzqAKh5KzHNfBdEQLKbZEG RcZEbtQMUKTyf5cTiWgKeBP8bPfyhlbifhh2K6ECgYEA8oygBo2D0CE2EQ39j/7n ouXXc2bbmZfFKwgEd6wZEDNZGVEnu6wcUbJIQr1Jpba03vH+NySxMcGcVc6sHRhj lD5bd5X6mRzr0/4RFHIs2pakOZkMLveY9kPBJmPhbAIgppH8dRtcc21egGeoIyLV EpKYISmpApSpbfJcb1MhDnA=";
	// TODO: change publicKey from IMEDIA
	// IMEDIA
	// private static String publicKey =
	// "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDSPRX5WI2KMBFIw+/kXaFdXO5ALE5VYcSxp3pR6BKMAcoAHdzXRUDoUmxU1XhuUGjiH5Oas35oQqqUv0gJrKytpTZsyAR+nlNBGbf5o1vaNeJYmV6FGQ2n8NbpB2apWm9Katpog6oVK3jM0a8kneanB69IRLNLzeH+FEyfbRI3vwIDAQAB";
	// VPB PUBKEY
	private static String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAx0uCHe77O49goG1K5bTg nMsKbMaDgEaBMvnC0QtMor93Bcn2teiLHU71bN56us/GYoj4NlSpoG5HDcUs80Pp 3VekabO4asVpVHzdHwhY5w+il+F0a82+EZV25kjc1qdOlCZ8FP4uoubQ48dKGjNG wkC//8BBnon2QpmIE/TcPWcb0oOMp3xjox3lAHoCdw1iaCky11nSMUjfmGI+YZjy aPzELtRoaO55CnsKWl2II6hRskzFD8C0mtx/YvhJKSmyFMp9msrMsTDNflmfbMud 8o6Y3oFeli7MgbDOej+ASpas9K6EnmBhIjFRZCJMnl2M8u0zsAv1DgVkbBOBmSfA DQIDAQAB";

	// static {
	// Security.addProvider(new
	// org.bouncycastle.jce.provider.BouncyCastleProvider());
	// }
	public static void main(String[] args) {
		String message = "VPBANK202012290144025342020-12-29 08:44:02BANK_VP09900000128TEST IMEDIA10000TEST NOTICE IMEDIA 03BANK_VP";
		String sign = IMediaUtil.sign(message);
		System.out.println("sign: " + sign);
		System.err.println("verify: "
				+ IMediaUtil.verify(publicKey, message, sign));
	}

	public static String sign(String message) {
		byte[] privateKeyBytes = Base64.getDecoder().decode(
				privateKey.replace(" ", ""));
		PrivateKey priKey;
		Signature sign;
		try {
			priKey = KeyFactory.getInstance("RSA").generatePrivate(
					new PKCS8EncodedKeySpec(privateKeyBytes));
			sign = Signature.getInstance("SHA1withRSA");
			sign.initSign(priKey);
			sign.update(message.getBytes("UTF-8"));
			return new String(Base64.getEncoder().encode(sign.sign()), "UTF-8");
		} catch (Exception e) {

			e.printStackTrace();
		}
		return null;

	}

	public static boolean verify(String publicKey, String message,
			String signature) {
		try {
			byte[] encoded = Base64.getDecoder().decode(
					publicKey.replace(" ", ""));
			KeyFactory kf = KeyFactory.getInstance("RSA");
			RSAPublicKey pubKey = (RSAPublicKey) kf
					.generatePublic(new X509EncodedKeySpec(encoded));
			Signature sign = Signature.getInstance("SHA1withRSA");
			sign.initVerify(pubKey);
			sign.update(message.getBytes("UTF-8"));
			return sign.verify(Base64.getDecoder().decode(
					signature.getBytes("UTF-8")));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

}
