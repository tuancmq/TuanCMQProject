package vn.com.vpbank.ghtk;

import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

public class GHash {
	private byte[] secretKey, hmacKey, iv;
	private static final int BANK_ID = 86;
	private static final String ALGORITHM = "AES";
	private static final String HASH_ALGO = "HmacSHA256";
	private static final String CIPHER_METHOD = "AES/CBC/PKCS5Padding";

	class Encrypted {
		public byte[] hash, data;

		public Encrypted(byte[] hash, byte[] data) {
			this.hash = hash;
			this.data = data;
		}

		@Override
		public String toString() {
			Base64.Encoder encoder = Base64.getEncoder();
			return "Encrypted{" + "hash=" + encoder.encodeToString(this.hash)
					+ ", data=" + encoder.encodeToString(this.data) + '}';
		}
	}

	public void setHmacKey(byte[] hmacKey) {
		this.hmacKey = hmacKey;
	}

	public void setSecretKey(byte[] secretKey) {
		this.secretKey = secretKey;
	}

	public void setIv(byte[] iv) {
		this.iv = iv;
	}

	public byte[] getHash(byte[] data) throws Exception {
		Mac mac = Mac.getInstance(HASH_ALGO);
		SecretKeySpec hmacKey = new SecretKeySpec(this.hmacKey, HASH_ALGO);
		mac.init(hmacKey);
		return mac.doFinal(data);
	}

	public Encrypted encrypt(byte[] input) throws Exception {
		SecretKeySpec sec = new SecretKeySpec(this.secretKey, ALGORITHM);
		IvParameterSpec iv = new IvParameterSpec(this.iv);
		Cipher cipher = Cipher.getInstance(CIPHER_METHOD);
		cipher.init(Cipher.ENCRYPT_MODE, sec, iv);
		byte[] data = cipher.doFinal(input);
		byte[] newData = new byte[data.length + this.iv.length];
		System.arraycopy(this.iv, 0, newData, 0, this.iv.length);
		System.arraycopy(data, 0, newData, this.iv.length, data.length);
		data = newData;
		byte[] hash = this.getHash(data);
		return new Encrypted(hash, data);
	}

	private boolean hashEqual(byte[] h1, byte[] h2) {
		boolean result = true;
		for (int i = 0; i < h1.length; i++) {
			if (i >= h2.length)
				result = false;
			if (h1[i] != h2[i])
				result = false;
		}
		return result;
	}

	public byte[] decrypt(Encrypted data) throws Exception {
		if (!hashEqual(this.getHash(data.data), data.hash))
			throw new Exception("Hash mismatch");
		SecretKeySpec sec = new SecretKeySpec(this.secretKey, ALGORITHM);
		byte[] currentIv = Arrays.copyOfRange(data.data, 0, 16);
		byte[] currentData = Arrays
				.copyOfRange(data.data, 16, data.data.length);
		IvParameterSpec iv = new IvParameterSpec(currentIv);
		Cipher cipher = Cipher.getInstance(CIPHER_METHOD);
		cipher.init(Cipher.DECRYPT_MODE, sec, iv);
		return cipher.doFinal(currentData);
	}

	private static final String SEC = "PlS5XwdmQXcEmg961hzOA2feJsk3PUKpchR2REDIrW8=";
	private static final String HMAC = "FD1lpZHGcF6hLXkfEsJ3HvwMV89o5MFO51iKPJuTm58=";

	public static void main(String[] args) {
		GHash gHash = new GHash();
		SecureRandom rand = new SecureRandom();
		byte[] sec = DatatypeConverter.parseBase64Binary(SEC);
		byte[] hmac = DatatypeConverter.parseBase64Binary(HMAC);
		byte[] iv = new byte[16];
		gHash.setSecretKey(sec);
		gHash.setIv(iv);
		gHash.setHmacKey(hmac);
		rand.nextBytes(iv);
		// String data =
		// "{\"code\":\"DLA002-0000277056\",\"timestamp\":1602577257}";
		String data = "{ \"virtual_acc_id\": \"00100000980\", \"timestamp\": 1597203865, \"ref\": \"BANKXX_123\", \"amount\": 1000000 } ";
		try {
			GHash.Encrypted encrypted = gHash.encrypt(data.getBytes());

			Base64.Encoder encoder = Base64.getEncoder();

			System.out.println("hash: "
					+ encoder.encodeToString(encrypted.hash));
			System.out.println("data: "
					+ encoder.encodeToString(encrypted.data));
			byte[] decrypted = gHash.decrypt(encrypted);
			System.out.println(new String(decrypted));
			
			System.out.println(buildGhtkMsg(data, SEC, HMAC, "86"));
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// DECLARE encData CHARACTER buildGhtkMsgJava(rawData, SEC, HMAC, BANK_ID);
	public static String buildGhtkMsg(String rawData, String SEC,
			String HMAC, String bankId) {
		GHash gHash = new GHash();
		SecureRandom rand = new SecureRandom();
		byte[] sec = DatatypeConverter.parseBase64Binary(SEC);
		byte[] hmac = DatatypeConverter.parseBase64Binary(HMAC);
		byte[] iv = new byte[16];
		gHash.setSecretKey(sec);
		gHash.setIv(iv);
		gHash.setHmacKey(hmac);
		rand.nextBytes(iv);
//		String data = "{ \"virtual_acc_id\": \"00100000980\", \"timestamp\": 1597203865, \"ref\": \"BANKXX_123\", \"amount\": 1000000 } ";
		try {
			GHash.Encrypted encrypted = gHash.encrypt(rawData.getBytes());						
			byte[] decrypted = gHash.decrypt(encrypted);
			System.out.println(new String(decrypted));
			
			Base64.Encoder encoder = Base64.getEncoder();
			return "{" + "\"hash\":\"" + encoder.encodeToString(encrypted.hash)
					+ "\"" + ", \"data\":\""
					+ encoder.encodeToString(encrypted.data) + "\""
					+ ", \"bank_id\":" + bankId + "}";
		} catch (Exception e) {
			e.printStackTrace();
			return "FAIL";
		}
	}
}