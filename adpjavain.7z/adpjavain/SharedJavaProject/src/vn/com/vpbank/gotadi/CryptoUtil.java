package vn.com.vpbank.gotadi;

import java.io.IOException;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.RSAPrivateCrtKeySpec;
import java.security.spec.RSAPublicKeySpec;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.codec.binary.Base64;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class CryptoUtil {

    /**
     * @param privateKey
     * @return
     * @throws Exception
     */
    private static Cipher createCipherDecrypt(PrivateKey privateKey)
        throws Exception {
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        return cipher;
    }

    /**
     * @param publicKey
     * @return
     * @throws Exception
     */
    private static Cipher createCipherEncrypt(PublicKey publicKey) throws Exception {
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
        return cipher;
    }

    /**
     * @param xml
     * @return
     * @throws ParserConfigurationException
     * @throws IOException
     * @throws SAXException
     */
    public static Document buildDocument(String xml) throws ParserConfigurationException, IOException, SAXException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        InputSource is = new InputSource(new StringReader(xml));
        Document doc = builder.parse(is);

        return doc;
    }

    /**
     * @param xml
     * @return
     * @throws Exception
     */
    public static PrivateKey getPrivateKeyFromXML(String xml)
        throws Exception {
        RSAPrivateCrtKeySpec pkeyspec = null;
        Document doc = buildDocument(xml);
        BigInteger modulus = new BigInteger(1, DatatypeConverter.parseBase64Binary(
            doc.getElementsByTagName("Modulus").item(0).getTextContent()));
        BigInteger publicExponent = new BigInteger(1, DatatypeConverter.parseBase64Binary(
            doc.getElementsByTagName("Exponent").item(0).getTextContent()));
        BigInteger privateExponent = new
            BigInteger(1, DatatypeConverter.parseBase64Binary(
            doc.getElementsByTagName("D").item(0).getTextContent()));
        BigInteger primeP = new BigInteger(1, DatatypeConverter.parseBase64Binary(
            doc.getElementsByTagName("P").item(0).getTextContent()));
        BigInteger primeQ = new BigInteger(1, DatatypeConverter.parseBase64Binary(
            doc.getElementsByTagName("Q").item(0).getTextContent()));
        BigInteger primeExponentP = new
            BigInteger(1, DatatypeConverter.parseBase64Binary(
            doc.getElementsByTagName("DP").item(0).getTextContent()));
        BigInteger primeExponentQ = new
            BigInteger(1, DatatypeConverter.parseBase64Binary(doc.getElementsByTagName("DQ").item(0).getTextContent()));
        BigInteger crtCoefficient = new
            BigInteger(1, DatatypeConverter.parseBase64Binary(
            doc.getElementsByTagName("InverseQ").item(0).getTextContent()));
        pkeyspec = new
            RSAPrivateCrtKeySpec(modulus, publicExponent, privateExponent, primeP,
            primeQ, primeExponentP, primeExponentQ, crtCoefficient);
        KeyFactory fact = KeyFactory.getInstance("RSA");
        PrivateKey privKey = fact.generatePrivate(pkeyspec);
        return privKey;
    }

    /**
     * @param xml
     * @return
     * @throws Exception
     */
    public static PublicKey getPublicKeyFromXML(String xml)
        throws Exception {
        RSAPublicKeySpec pkeyspec = null;
        Document doc = buildDocument(xml);
        String modulus =
            doc.getElementsByTagName("Modulus").item(0).getTextContent();
        byte[] modulusBytes =
            DatatypeConverter.parseBase64Binary(modulus);
        BigInteger bigModulus = new BigInteger(1, modulusBytes);
        String exponent =
            doc.getElementsByTagName("Exponent").item(0).getTextContent();
        byte[] exponentBytes =
            DatatypeConverter.parseBase64Binary(exponent);
        BigInteger bigExponent = new BigInteger(1, exponentBytes);
        pkeyspec = new RSAPublicKeySpec(bigModulus, bigExponent);
        KeyFactory fact = KeyFactory.getInstance("RSA");
        PublicKey pubKey = fact.generatePublic(pkeyspec);
        return pubKey;
    }

    /**
     * @return
     * @throws Exception
     */
    public static byte[] generateKey() throws Exception {
        KeyGenerator keyGenerator = KeyGenerator.getInstance("DESede");
        SecretKey secretKey = keyGenerator.generateKey();
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DESede");
        DESedeKeySpec deSedeKeySpec = (DESedeKeySpec) secretKeyFactory.getKeySpec(secretKey, DESedeKeySpec.class);
        byte[] randomKey = deSedeKeySpec.getKey();
        return randomKey;
    }

    /**
     * @param encryptedData
     * @param randomKey
     * @return
     * @throws Exception
     */
    public static String decryptTripleDes(String encryptedData, byte[] randomKey) throws Exception {
        Cipher cipher = Cipher.getInstance("DESede");
        SecretKeySpec secretKeySpec = new SecretKeySpec(randomKey, "DESede");
        cipher.init(Cipher.DECRYPT_MODE, secretKeySpec);
        byte[] originalData  = cipher.doFinal(Base64.decodeBase64(encryptedData));
        return new String(originalData, "UTF-8");
    }

    /**
     * @param originalData
     * @param randomKey
     * @return
     * @throws Exception
     */
    public static String encryptTripleDes(String originalData, byte[] randomKey) throws Exception {
        Cipher cipher = Cipher.getInstance("DESede");
        SecretKeySpec secretKeySpec = new SecretKeySpec(randomKey, "DESede");
        cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);
        byte[] encryptedData = cipher.doFinal(originalData.getBytes("UTF-8"));
        return Base64.encodeBase64URLSafeString(encryptedData);
    }

    /**
     * @param encryptedKey
     * @param privateKey
     * @return
     * @throws Exception
     */
    public static byte[] decryptRSAToByte(String encryptedKey, PrivateKey privateKey) throws Exception {
        Cipher cipher = createCipherDecrypt(privateKey);
        byte[] bts = Base64.decodeBase64(encryptedKey);
        byte[] randomKey = cipher.doFinal(bts);
        return randomKey;
    }

    /**
     * @param randomKey
     * @param publicKey
     * @return
     * @throws Exception
     */
    public static String encryptRSA(byte[] randomKey, PublicKey publicKey) throws Exception {
        Cipher cipher = createCipherEncrypt(publicKey);
        byte[] encryptedKey = cipher.doFinal(randomKey);
        return Base64.encodeBase64URLSafeString(encryptedKey);
    }

    /**
     * @param signedData
     * @param signature
     * @param publicKey
     * @return
     * @throws Exception
     */
    public static boolean verifyRSA(String signedData, String signature, PublicKey publicKey) throws Exception {
        Signature instance = Signature.getInstance("SHA256withRSA");
        instance.initVerify(publicKey);
        instance.update(signedData.getBytes("UTF-8"));
        return instance.verify(Base64.decodeBase64(signature));
    }

    /**
     * @param signatureData
     * @param privateKey
     * @return
     * @throws Exception
     */
    public static String signRSA(String signatureData, PrivateKey privateKey) throws Exception {
        Signature instance = Signature.getInstance("SHA256withRSA");
        instance.initSign(privateKey);
        instance.update(signatureData.getBytes("UTF-8"));
        byte[] signature = instance.sign();
        return Base64.encodeBase64String(signature);
    }

    public static String decodeBase64(String base64String) throws UnsupportedEncodingException {
        return new String(Base64.decodeBase64(base64String.getBytes("UTF-8")), "UTF-8");
    }

    public static String endcodeBase64(String data) throws UnsupportedEncodingException {
        return Base64.encodeBase64String(data.getBytes("UTF-8"));
    }

//    public static byte[] getTripleDesKeyBytes(String key) throws UnsupportedEncodingException, NoSuchAlgorithmException {
//        MessageDigest md = MessageDigest.getInstance("md5");
//        byte[] digestOfPassword = md.digest(key.getBytes("utf-8"));
//
//        return digestOfPassword;
//    }

}
