package vn.com.vpbank.gotadi;

import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.Arrays;

public class GotadiUtil {
	private static String gotadiPublicXMLKey = "<RSAKeyValue><Exponent>AQAB</Exponent><Modulus>jcOCO75czHV3e9l2KcKMtdnRjvPCg107tGgvFpRk0o9ctyAdIGUTEUNLrasBDuMihX802tLY7jTpjUhxQsXbL2xaMYK0tfbQ/5F8tLYuwzGLIb2DN/RComToJL5Ob9xxSyTCvmFGqzMVrxjr7E/J/paoRTjmCuWIv36cy+/+NP6JIwnGcmDlzg9qrMAwEp4dKqAWlZ1txj4V//Je7dSjgkH5Y0SB6bCwmOqcMjVhuCQYwZU7YMrzXbrIV8sgmWhNiHIkY8xWiudEBtx91IUS0PZlJgNyfeNQ9PvYk56Jqqn5oLq7TQ4GrBjbymK6xG7jd56RP2cATBukh1PG/JAgHw==</Modulus></RSAKeyValue>";
//	private static String gotadiPublicXMLKey = "";
	private static String partnetPrivateXMLKey = "<RSAKeyValue><Modulus>x0uCHe77O49goG1K5bTgnMsKbMaDgEaBMvnC0QtMor93Bcn2teiLHU71bN56us/GYoj4NlSpoG5HDcUs80Pp3VekabO4asVpVHzdHwhY5w+il+F0a82+EZV25kjc1qdOlCZ8FP4uoubQ48dKGjNGwkC//8BBnon2QpmIE/TcPWcb0oOMp3xjox3lAHoCdw1iaCky11nSMUjfmGI+YZjyaPzELtRoaO55CnsKWl2II6hRskzFD8C0mtx/YvhJKSmyFMp9msrMsTDNflmfbMud8o6Y3oFeli7MgbDOej+ASpas9K6EnmBhIjFRZCJMnl2M8u0zsAv1DgVkbBOBmSfADQ==</Modulus><Exponent>AQAB</Exponent><P>9hyAXoNcXo2IHSmewBJLb17wcyhtJ+F+8BpmzC4Mi5iAlJt8FUwXJzJomLAQCp3YHlWU8c1NaI29of30d7CGqP36mXZ1KU325XhZhHScdGeE7CKP0lDcPIlK1QidckTbNyyjHs5M7yrDhcOlS6m7ARe2GFTccAUwNWnBqDg3Ut8=</P><Q>z010PFCaKwzNpFvoByUGMzN9wF8jAQA+tbP6azgR6QO2Dmb1oCoE75JRFB3oevBRK203CGz6btwBoPyD7vqnVdVMogMLVZp+lZXvXX0ZRM5vQpxAHLKOlnYWAx3WxRngYruBQs5DZBZilP9999DBFkg/O/H3VeQUtsiLS1w8FpM=</Q><DP>Z7H4kFnuqFQfvpHTtn++0u0AiLTG0R/cmRO2rl7UoFigDH06mcqWkshVc8fy6lY5QgazG/JxpBTcio1y3J8/DaL9XH2hvcaAuYyswvdTGGSph8jEKkwxjzwVkI7xr7y9VJD1Jbysg7TT7t9RHQElrr8r1TKkMnqtJkQp+VO+U6c=</DP><DQ>eob9POknNmrK4WqxKgfoMjstCJcyyVSrvBo02Uq6y082PCz+4Tv0zuVcptdGoeOJFnHnJUPEgeHn1I9sK8RbQ5BfSyMhf+dhCmkkoc1fMhwSBvzzqAKh5KzHNfBdEQLKbZEGRcZEbtQMUKTyf5cTiWgKeBP8bPfyhlbifhh2K6E=</DQ><InverseQ>8oygBo2D0CE2EQ39j/7nouXXc2bbmZfFKwgEd6wZEDNZGVEnu6wcUbJIQr1Jpba03vH+NySxMcGcVc6sHRhjlD5bd5X6mRzr0/4RFHIs2pakOZkMLveY9kPBJmPhbAIgppH8dRtcc21egGeoIyLVEpKYISmpApSpbfJcb1MhDnA=</InverseQ><D>JSCC9/KaaQkX1ismJc7hfTQyF/uPaek4jneK/IifWT5T/QcX5+GPcQFRpVt4/65PZfHgU7bH9vQ0VnNiIVuIiMyX+30YoQNv0OaGBw72CO2Xu7Wri53Dh+ERSmtOgMqgT+cvfHWx2HUpexWYT3M3/l4zpoB5eQB4mQWjHRyjnuhvBYGDuYUZDkPCoFgJtKDUZwu0HngSC5iDRoeUdmrmXqyWZ39nmObqmdYhCFOU/KayosKahtRCWLD6nPkeB5xJU64RNsRx4zBKdkgYFIMKnrwhgw/6GhxaMhWVbRzU0+N3FAHz7ZWF0GPXZHy+himtTpjQzPhDiBQ3EYRU1rmF3Q==</D></RSAKeyValue>";
	private static PublicKey gotadiPublicKey = null;
	private static PrivateKey partnerPrivateKey = null;
	private static byte[] randomKey = null;
//	private static String strEKey = null;

	public static String encryptedData(String signatureData, String originalData, String publicXMLKey) {
//		EncryptedBody encryptedBody = new EncryptedBody();
		StringBuffer sbfJSon = new StringBuffer();

		try {
			// Step 1: Generate random 3DES key.
			if (gotadiPublicKey == null 
					|| partnerPrivateKey ==  null) {		
				if (publicXMLKey != null) {
					gotadiPublicXMLKey = publicXMLKey;
				}
				gotadiPublicKey = CryptoUtil.getPublicKeyFromXML(gotadiPublicXMLKey);
				partnerPrivateKey = CryptoUtil.getPrivateKeyFromXML(partnetPrivateXMLKey);
				
			}
			
			// Step 2: Encrypt key
			randomKey = CryptoUtil.generateKey();
			String strEKey  = CryptoUtil.encryptRSA(randomKey, gotadiPublicKey);
			// encryptedBody.setKey(strEKey);
			// Step 3: Sign
			sbfJSon.append("{\"key\":\"" + strEKey + "\",");
			String signature = CryptoUtil.signRSA(signatureData,partnerPrivateKey);
			// Step 4: Encrypt data
			originalData = originalData.replaceFirst("<<signature>>", signature);
			String strEData = CryptoUtil.encryptTripleDes(originalData,randomKey);
			// encryptedBody.setData(strEData);
			sbfJSon.append("\"data\":\"" + strEData + "\"}");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sbfJSon.toString();
	}

	public static String decryptedData(String key, String data, String api, String publicXMLKey) {
//		DecryptedData decryptedData = new DecryptedData();
		StringBuffer sbfJSon = new StringBuffer();
		try {
			if (gotadiPublicKey == null 
					|| partnerPrivateKey ==  null) {
				if (publicXMLKey != null) {
					gotadiPublicXMLKey = publicXMLKey;
				}
				gotadiPublicKey = CryptoUtil.getPublicKeyFromXML(gotadiPublicXMLKey);
				partnerPrivateKey = CryptoUtil.getPrivateKeyFromXML(partnetPrivateXMLKey);
				// Step 1: Decrypt random 3DES key.
				
			}
			
			randomKey = CryptoUtil.decryptRSAToByte(key, partnerPrivateKey);
			// Step 2: Encrypt data
			String decryptData = CryptoUtil.decryptTripleDes(data, randomKey);
			// decryptedData.setOriginalData(decryptData);
			ArrayList<String> fields = new ArrayList<String>(
					Arrays.asList(decryptData.split("\\|", -1)));
			if (api.equalsIgnoreCase("createSessionGotadiRs")) {
				//<access_code>|<error_code>|<redirect_url>|<signature>
				sbfJSon.append("{\"access_code\":\"" + fields.get(0) + "\",");
				sbfJSon.append("\"error_code\":\"" + fields.get(1) + "\",");
				sbfJSon.append("\"redirect_url\":\"" + fields.get(2) + "\"}");
			} if (api.equalsIgnoreCase("placeOrderRs")) {
//				COMMIT
//				<access_code>|<booking_number>|<error_code>|<product_type>|<properties>| <return_url>|<signature>|<total_amount>
				 
				sbfJSon.append("{\"access_code\":\"" + fields.get(0) + "\",");
				sbfJSon.append("\"booking_number\":\"" + fields.get(1) + "\",");
				sbfJSon.append("\"error_code\":\"" + fields.get(2) + "\",");
				
				sbfJSon.append("\"product_type\":\"" + fields.get(3) + "\",");
				sbfJSon.append("\"properties\":" + fields.get(4) + ",");
				sbfJSon.append("\"return_url\":\"" + fields.get(5) + "\",");
				sbfJSon.append("\"total_amount\":\"" + fields.get(7) + "\"}");
				
			}
			
			

			/*
			 * // Step 3: Verify signature ArrayList<String > fields = new
			 * ArrayList(Arrays.asList(decryptData.split("\\|", -1))); int
			 * signatureOffset = 3; String signature =
			 * fields.get(signatureOffset); fields.remove(signatureOffset);
			 * String signatureData = String.join("|", fields); boolean
			 * verifyRSA = CryptoUtil.verifyRSA(signatureData, signature,
			 * gotadiPublicKey); decryptedData.setVerifySignature(verifyRSA);
			 */
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sbfJSon.toString();
	}
}
