package vn.com.vpbank.ldap;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Objects;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

public class LDAPUtils {
	//private static String BASE_DN = "OU=VPBank,DC=vpbank,DC=com,DC=vn"; // for prod
	private static String BASE_DN = "OU=VPBank,DC=vpbank,DC=com"; // for uat
	private static String UID_ATTRIBUTE = "sAMAccountName";
	private static InitialDirContext initialDirContext;
	private static Hashtable<String, String> env;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private static void connect(String url, String username, String password)
			throws NamingException {		
			env = new Hashtable();
			env.put(Context.INITIAL_CONTEXT_FACTORY,
					"com.sun.jndi.ldap.LdapCtxFactory");
			env.put(Context.PROVIDER_URL, url);
			env.put(Context.REFERRAL, "ignore");
			if (username != null && !username.isEmpty()) {
				env.put(Context.SECURITY_AUTHENTICATION, "simple");
				env.put(Context.SECURITY_PRINCIPAL, username);
				env.put(Context.SECURITY_CREDENTIALS, password);
			}
			initialDirContext = new InitialDirContext(env);		
	}

	private static List<Attributes> searchObject(String uRL, String user,
			String password, String baseDN, String filter) {

		List<Attributes> results = null;
		try {
			connect(uRL, user, password);
			SearchControls ctrls = new SearchControls();
			ctrls.setSearchScope(SearchControls.SUBTREE_SCOPE);
			NamingEnumeration<SearchResult> answers = initialDirContext.search(
					baseDN, filter, ctrls);
			results = new ArrayList<Attributes>();
			while (answers.hasMore()) {

				SearchResult entry = answers.next();
				results.add(entry.getAttributes());
			}

		} catch (Exception e) {
			return null;
		}

		return results;

	}

	public static String searchLdapUser(String ldapServer, String bindingUser,
			String bindingPassword, String uid) {
		try {
			String filter = "(" + UID_ATTRIBUTE + "=" + uid + ")";
			StringBuilder response = new StringBuilder();
			List<Attributes> result = searchObject(ldapServer, bindingUser,
					bindingPassword, BASE_DN, filter);
			for (Attributes attributes : result) {
				if (Objects.nonNull(attributes.get("sAMAccountName")))
					response.append(attributes.get("sAMAccountName").toString()
							+ "**sAMAccountName||");
				if (Objects.nonNull(attributes.get("displayName")))
					response.append(attributes.get("displayName").toString()
							+ "**displayName||");
				if (Objects.nonNull(attributes.get("mail")))
					response.append(attributes.get("mail").toString()
							+ "**mail||");
				if (Objects.nonNull(attributes.get("mobile")))
					response.append(attributes.get("mobile").toString()
							+ "**mobile||");
				if (Objects.nonNull(attributes.get("title")))
					response.append(attributes.get("title").toString()
							+ "**title||");
				if (Objects.nonNull(attributes.get("department")))
					response.append(attributes.get("department").toString()
							+ "**department||");
				if (Objects.nonNull(attributes.get("company")))
					response.append(attributes.get("company").toString()
							+ "**company||");
			}

			return response.toString();
		} catch (Exception e) {
			return e.getMessage();
		}
	}
}
