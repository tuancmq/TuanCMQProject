package vn.com.vpbank.secure;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.binary.Base64;

public class SHAUtils {
	private static final Charset UTF_8 = StandardCharsets.UTF_8;
	private static final String ALGORITHM = "AES";
	private static final String TRANSFORMATION = "AES/ECB/PKCS5Padding";

	// private static final String OUTPUT_FORMAT = "%-20s:%s";
	private static String encryptSHA(String KEY, String VALUE, String SHA_TYPE) {
		try {
			SecretKeySpec signingKey = new SecretKeySpec(KEY.getBytes("UTF-8"),
					SHA_TYPE);
			Mac mac = Mac.getInstance(SHA_TYPE);
			mac.init(signingKey);
			byte[] rawHmac = mac.doFinal(VALUE.getBytes("UTF-8"));
			byte[] hexArray = { (byte) '0', (byte) '1', (byte) '2', (byte) '3',
					(byte) '4', (byte) '5', (byte) '6', (byte) '7', (byte) '8',
					(byte) '9', (byte) 'a', (byte) 'b', (byte) 'c', (byte) 'd',
					(byte) 'e', (byte) 'f' };
			byte[] hexChars = new byte[rawHmac.length * 2];
			for (int j = 0; j < rawHmac.length; j++) {
				int v = rawHmac[j] & 0xFF;
				hexChars[j * 2] = hexArray[v >>> 4];
				hexChars[j * 2 + 1] = hexArray[v & 0x0F];
			}
			return new String(hexChars);
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	private static byte[] digest(byte[] input, String algorithm) {
		MessageDigest md;
		try {
			md = MessageDigest.getInstance(algorithm);
		} catch (NoSuchAlgorithmException e) {
			throw new IllegalArgumentException(e);
		}
		byte[] result = md.digest(input);
		return result;
	}

	private static String bytesToHex(byte[] bytes) {
		StringBuilder sb = new StringBuilder();
		for (byte b : bytes) {
			sb.append(String.format("%02x", b));
		}
		return sb.toString();
	}

	public static String encryptSHA256(String value) {
		String hmacSha = "";
		try {
			byte[] shaInBytes = SHAUtils.digest(value.getBytes(UTF_8),
					"SHA-256");
			hmacSha = bytesToHex(shaInBytes);

		} catch (Exception e) {
			hmacSha = "FAIL";
		}

		return hmacSha;

	}

	public static String encryptSHA256(String key, String value) {
		String hmac = "";
		try {
			hmac = encryptSHA(key, value, "HmacSHA256");
		} catch (Exception e) {
			hmac = "FAIL";
		}

		return hmac;

	}

	/**
	 * Encrypt with secret key
	 * 
	 * @param input
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public static String encryptWithSecretKey(String input, String key) {
		byte[] crypted = null;
		try {
			SecretKeySpec skey = new SecretKeySpec(key.getBytes(UTF_8),
					ALGORITHM);
			Cipher cipher = Cipher.getInstance(TRANSFORMATION);
			cipher.init(Cipher.ENCRYPT_MODE, skey);
			crypted = cipher.doFinal(input.getBytes(UTF_8));
		} catch (Exception e) {
			System.out.println(e.toString());
			return "";
		}

		return new Base64().encodeToString(crypted);
	}

	/**
	 * Execute encode url
	 * 
	 * @param url
	 * @return Encoded URL string
	 */
	public static String urlEncode(String url) {
		String encodeUrl = "";
		try {
			encodeUrl = URLEncoder.encode(url, "UTF_8");

		} catch (UnsupportedEncodingException e) {
			System.out.println(e.toString());
		}

		return encodeUrl;
	}

	public static String checksumByAlgorithm(String value, String algorithm) {
		try {
			return bytesToHex(SHAUtils.digest(value.getBytes(UTF_8), algorithm));
		} catch (Exception e) {
			return "FAIL";
		}
	}

	public static void main(String[] args) {
		System.out.println(encryptSHA("CTIN@123Vina", "ABCDEF", "HmacSHA256"));
		// String algorithm = "SHA-256"; // if you perfer SHA-2
		// String algorithm = "SHA3-256";
		System.out
				.println(encryptSHA(
						"VPBANKCCE978035456097CC77D6140UTV",
						"nsd=vpbank.utv@gmail.com&so_id_dtac=2487671088&nv=UTV&ten=thao&dia_chi=hn&ngay_sinh=19620303&gioi_tinh=&cmt=123456789",
						"HmacSHA256"));
		System.out
				.println("encryptSHA256: "
						+ encryptSHA256("sohopdong=VPB/ATNCN/200821/00000341&transactionCode=FT20197351304060&transactionPaymentAmount=2450000&transactionDate=2020-08-21 21:29:45&key=0abbc84a"));
		// --String pText =
		// "1000FT201951975341491420791192020-07-04 14:58:41Nop tien aaaaaVNDCTIN@123Vina";
		// System.err.println("HELLO: " + hashSHA256(pText));
		/*
		 * System.out.println(String.format(OUTPUT_FORMAT, "Input (string)",
		 * pText)); System.out.println(String.format(OUTPUT_FORMAT,
		 * "Input (length)", pText.length()));
		 * 
		 * byte[] shaInBytes = SecureUtils.digest(pText.getBytes(UTF_8),
		 * algorithm); System.out.println(String.format(OUTPUT_FORMAT, algorithm
		 * + " (hex) ", bytesToHex(shaInBytes))); // fixed length, 32 bytes, 256
		 * bits. System.out.println(String.format(OUTPUT_FORMAT, algorithm +
		 * " (length)", shaInBytes.length));
		 */
			System.out.println("checksumByAlgorithm: " + checksumByAlgorithm("18288196150000020210109FT21008001030137VPBANK202101121613258702021-01-12 16:13:25", "MD5"));
	}
}
