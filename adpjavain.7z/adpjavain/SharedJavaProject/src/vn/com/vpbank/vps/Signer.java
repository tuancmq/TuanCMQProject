package vn.com.vpbank.vps;



import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.Signature;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.Enumeration;

import javax.crypto.Cipher;
import javax.net.ssl.KeyManagerFactory;

import org.apache.commons.codec.binary.Base64;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

public class Signer {
	public static final String ALGORITHM = "RSA/None/OAEPWithSHA1AndMGF1Padding";
	public static final String PRIVATE_KEY_FILE_PATH = "/opt/esb/credentials/vpbs/vpbPrivate.pfx";
//	public static final String PRIVATE_KEY_FILE_PATH = "D:/vpbank/work-space/uat/b2b/AdpVPSJava/libs/vpbPrivate.pfx";
	// public static final String CERT_FILE =
	// "E:\\Documents\\Datapower\\VPBS\\vpbspublic.cer";
	public static final String CERT_FILE = "/opt/esb/credentials/vpbs/vpbsPublic.cer";
	public static final String PASSWORD = "haint83vn";
	public static final String CHARSET = "UTF-32LE";

	KeyPair keyPair = null;

	static {
//		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		Security.addProvider(new BouncyCastleProvider());
	}

	public static void main(String[] args){
		System.out.println("Signer.main()");
//		String plainText = "<?xml version=\"1.0\" encoding=\"utf-8\"?><AccountInfo><AccountNo>002777</AccountNo><AccountName>Nguyen Minh Tam</AccountName><Birthday>7/7/1982</Birthday><IDCardNo>001082002542</IDCardNo><IDCardDay>6/25/2014</IDCardDay><IDCardPlace>CÃ¡Â»Â¥c CS Ã„Â�KQL CT vÃƒÂ  DLQG vÃ¡Â»Â� DC</IDCardPlace><ImgSignaturePath>http://10.36.10.107/signature/uploadedFiles/002777.jpg</ImgSignaturePath><AuthName /><AuthIDCardNo /><AuthIDCardDay /><AuthIDCardPlace /><AuthImgSignaturePath /><AuthMoneyTrans /><Signature>nX1ZKxqot0eL0QzLRbQ1cDz5tIcJdFCqM2TDNJoQWPA6GfED9JIbPRyRF8s/z1LAyB54w0pPUNo5s/dxp10DETe3ESj3cxcnyiMOQLjJQCF6GTcHkpVIfTm1tDGNX10GzL918AE/3B+5omWWGwTskPUdrykBFw5c6Ct4T6TcpnE=</Signature></AccountInfo>";
		// String plainText = "<?xml version=\"1.0\" en";
//		String t = encryptText(plainText, CERT_FILE);
		// String encrytedText =
		// "4tliL5o9OL3aPknvnfKgKI2wPPHysD4iRxQIAoyV2yzuj7bpYH5O3l7i8JEsVnMkItiDdv4w+1bm5OjfKobw5dAkkntdeuu81oM3bKBY2UXta0jZJDNbalf/4t366gYCBEUHUT0JKvU83v+ifz3TcjXqUWGe9JuwRbh9cdj6ATM=Vvz6GsH1HaJ/OAsN9fceSDFa6srspWhG62fnAPYoyOr7LUE0aT8YdbZ4VGjhiQeh8aQENXB9CXhX47NmF6gHKhBOeQLhRT8bsLpEm7ntUuEIiMowT8nDWgg0H961YOHztacdbe7mcA5Qxe4krgj+Ncvca2fX3HvGoDdCpJRkMK4=8TyELn1OAor3+odYLdFHbbta7mGTJT+wC4hhhHdPTKpN3IxcFKpeFDGsDIx1RgbkmIgQNOOHsgk+55fLUvMk8S/wLiX95OWlXFWiwecW/plKXoiNJ398HxzTWRwPvBTDBg0oUwEEjo9vjZrkpDHFuUK16oKSQrLKxfE45VpbnFU=Oim5sHBWKxsB2RkICZ5OJpgmWSGtzCuKBYCoUxPgNGJ4LzgBF7k2TaKke90pGoPqQqFZqC+lOqo6/9waRJm6y/29huAEeBNg8j2bkDYqhNDj0KDjdlgF4FEGzFr619dhoRtTk+wVO0BPMjnvUAk2lEuD5krkXfteTqjMT9tvjSY=9A9YaTetQJOeOe8KEa4dMgUSZkDgJQxlFiGQEOIW/DpZlXFQCtrvkSbOWlcZ1Uhf9KqyP1dX8Gq8C4Yj7CQZRNloNoA24MCD3ruZ7m9u22JND//At3BnXcNUyzly26JXJB55Xzkj6NeAuVR0uDtBbEkfTMiu6CSiSuJSmmbcLH0=BmBBgApbbw0ewvI7/bjSUVl3jLoFE5CBmbeLpEX6Ck1MRPejy/4zCqM3vrhpOo3So43x8TI5hPbJcSRr2Y+fdf7LNqlRm99YpCo8FLO8GxvDoTJi8JZ5UFk+sxoP4Jc7+sZAjun+Rsw6KxamKsRq9e/Uq8yD0ju5oESp/Y3IsFY=A6/3g+9hbpncMxCrcQytAJwe9/cjaK1qAh32pJZml8/xtTMJkqK68YKpWPDak9VtLiyb/XL71NI+BZchVbfR251IQYs33VQZbuJP+Pc/SM0+CySrnd3kNFk+MecLctI4Wop8fur2CCYh+CGTgQrpQTw67B5//rWMRFHodKenEBE=QXNq1D+Ku4KVnztFOlR5ASWQGCWf+Um9nh5DEaif3LT0lmY89Yaruv9ENU6qEq71mb4SN1uHOaHDc5A6Qlgfy7oZGf1eHI2Uq1wo3f6nu/UYbAuYzRxSxXvUdwyQ0GnV4t2KEh9se3bxUt62g0VQgIh5N6QDn8vLXANaMvvs+3I=V/CUEwXztStlc+kg/Y9Us+lKiwTwgQXh5sipMz98N0URCFkPwbqXRQGly/ctm0Zf9BZbPhw3XNsTDIOj1esOrHfSYt/zmfLMtdekZle6eKAc8DHhmyadRlojLnUaM9fM/1IDSBBkvoyOYHtHdWhe6kvjQpKA0pv2nGeRnJLRPlM=mjY0AWMd4z3hwso1gzPCVdviV/cvZTtirxp1wl+PLvHvKszA2NDURKycUNa4yQZnXlcH+GEKqDqWp8IewQp0i3/r3TpTzU7QiEML4q1Su34y1iW395UNBMoToIO3L5TKzpjvm553PmlqexYc1VbZGt1WW1UM3jlkwJ/HN5PpXh8=UgrrNqOd0P3pvXACtIQ4oxYChZqnRdCgNoogVVZ0zICPdQRZdkFNx5cA3kNERqwjVIyjrTwb8gT65OT0qeBVPCzh1ozWNg/9Cr3pvarpvHXBp8OwxPj9Ta1zEjaB6WKSxFMw8mXllaPRLurughBbTMB84N+Lp2A4vVn0L2lIrhE=q94wjxM6gei9DRn2+Z7nly7hQ31pMOioM+OvQTUybL8X9J06uDfA9tWFC8XjyAC2kwZE59LSAz6r71/vFTLmVbpyhnHFCNqKLvxHZzWQbmoTkRHy4Gg1go3M6qUUOjomO9Jeqbmpj2oV12dlF9Qv32XhXrdMHppiprXJEWzWBkw=LTk08puVH/wf6SrEOXqLCDTfv1COfbqz7IdvGOT45+0vWEF2XBJNDS61Xy3nTgqvey/GA4ZaNB/m6s+kvCaNFn3PFH8VWxprSTbjSEok3zBir2IUmABX1nHT8+7BK/tTvAWABWdZG1Rbu2gHujputgs98ts9jTYtLe4mefo+TiI=axp0e3zBnE6ePo8HMC+KZkoq+qqqZ5U3gbixs08x8lBvYExKAFUXYlMYy+IdDM3zhiZlFX7RoQ2ZhPQOYF2sFGlFAw4O9UDFe6fvxzO7CF7Gq9c4krUvhom69WR/lLVt/rhdJ38VpDOWgsaBMQsEzO9Q49JB+iKr1OS1hBZoNDk=enUm+BLvsIsItzaASTQrSX/JdYpR0DG5wk/vdncp2pV7rBsRMrUUbiDH/DQJeNEHRTI67QiOQbguC20cnnCusmL7AWs5zHT6Wklg6tHH2XKXsiAHFHGDgzhlRVLuW4qJwIaHaN+Wp3bPQwBP1u3S3N5am9eF0BtUi0jlH+IGzSU=tXOtON0+4webgaOAYYDMgXTZX/iOiw5DOdxjW3SYX1lzk21ikNyOuQMWh6z5La7pzOgi9G90RYbTJxfoaFUWdO1p5ijG/cYENdW9FekT5+o9dvmZhLcK0D3hX/fbLSlpjlJR//7XGl55oXKPia1ugRL0Y/slC/moSvmRJfNqgSU=7XWF0Ipp4J9AkM7dpx4KU4oQJziLTtQko7hCGOjVyanEK6djSGeS83CN5pgOFwwpWT3YOEeqq59QO/nLlsdadq6I/x89Ijh3WsBGbs8ldQm/uqRU9tjviiCjh5YICVsE86TtXctPgHPpdriEfqFyaYcLcCZnhyHaAxA20WHQthY=OOS7v2gATeBbQgprrPcUvY73gozeV8zRuPIacQf6yot2fK8Hl1FeuQoKjTSFF5SDGzbsknvRPXzNtnRFtfqpPA5m9gOqIAM12a251dHvOtumBojkUMK0OyAmrI2aDRc28rF8Ygj5s13S1KA+xaz+lPBPdJEGO82vqtbouZGGQR0=v9eS3iyulE3o1WQm/m/iKbdddD47lU5LKCHUXus2btXmmLK//qUNvA32dAuNY4iFyJDnVMTBG2fjIthiQPRgcZBkzk0CozsGyiRNZL8Km3mOTFtiNX54Z29kz712cLh0PuFyPnGAFYA1QUThWJYXCeBAI6DtxNy7V9XZ7HC3qY8=h0kUEOAFbw4i9eKJ9iSQnSU5/JEo8uE/AOW+xh87mkE6Rcsb2tFTM6dBVdKm4i/Pxr4l6fL0uxrOOYs0ITA/78kDuV1kU/EsQOFb2Q+xVB6DiADPkLzRste/ZtuJhkWAt4l26139IhfrCtPgmlQ2IlZhX94RjdMSg2iobXkMC6E=oUtCoSqaY8EwI06qbLm2IvBeIst8VkawFHCwIBy09/6DyYGGt0MnJ6YSnV/5CcN4bDzRO7wMAtX5fqzS6YrNMbaVr61nTqDZ3Sujj7HYn2Bu8fzzJb2Y4VjnyD+8xpNisxg0E1eXWzvpSU+SZjllHisIwWZvUgTOme6W1rCWKwg=rkKkRIcOugeHLfLWVc9ml38w3ZicCFQuehd4KFTwuYmzU3lm77FfQ9BEIGU6hhMgmvDKojJW03HBSYYwaSpR63VpTEmHWTTy88owsJsrTAyR3lVsn3/vhrFoWJ9N0rFMaoPngfbLJu3GipI3OzyHgTHu9vCRWlcK6ZJ20l/IY3A=QDFNpNYLVmMyOm9NzKpWJpXlHUCaAeWM1nw8FQVPEW2apdrXF9Q4Mw3Xii4K9+6XA2YkIH7A/2950A7KwhBAcCCnJYO2YIf9o0kNkn8kIkMSwdGw9KhWpO/8WjXUypzNEmTdRuOhtKNpI4SlyZPu4CiOKhvs0qep5+sxMIUfpgI=VD9Wfb1nHjgFjkBHgHPhkdLwAITdr3fDuTbY3zepnUB4fQbIqnyoV4BJJoIWvjrBKIVmkh54TafxExNCY/iv+xzhDh24uFBf0M+kyxcJyR96KEMxTOT43vIuwOC1XlJdeL4qbY7d3ZMXbi1tBB6AcBwdgdwWiiUnizbOX0RU3oU=/1zUNO2obgzea2XuORILcNbsiyVR/T73Vf8W8K04NtZpk+Y3rsR4mf97jViX8kVvYhdX+5ZPMSl+LYb4Qumer4ZgnJ8daURuQB8ao4zR0jUXvoYC8v2KA2datC4fJWoak69018MfUZuOEOIkpUztkRcLJ7pDqI13IOUWFt3UKyI=JvjUPb8xW6cbKXqpgi8Rz7M3432jnjxmhQszKX5QyloYqUjcHg9JzguYV4vEYvhLCPZ24chT7KBweO2jOBIYVP5akanw/Jm4Jf6WZ61M9Msy2b5Rjozk/2Hs9rrVHZO5VGSsdAMsuZJQH/SZiMxF158rStlsDsKJ2T3HdRVWIDE=+rW6+mpjY5OKoVlfExNfJIgh1m8Q9FHs8wVdeqkPYIBAUMIUDvY148JTid6c3hwi26Co1ODBOHhi/JPrv39x6sn5+mGSuQvk2aC7qXAodbC9PlhJkjNDOq8On6UuuOwv1fZIAkjsSAughRBFCS6YXs1Th9rPGScia/AVQeAEfpE=x54b0ltJ6f+dhZRvNWl9xPyzEJLJCWQBLf51cH7XrvsYfXoN1xtxMb/hGhc0la/94Waf+7YxxUsvw6D36xw7Q8R510Yh/OwZ0Yc2s2+Sf7oxUFC/jcNfbb+HGc4KtCAptniI3xFRfOFA8W9vO6U6/xTFUgNb87pVLZ9QC3fFFHw=bitwFOyAuNnATjqD7mGKX8o+R33fNxoUIkwWa7RxP9Fcp0u8F+kq3WhhTogWTol8EukUdJN7+hzirnqQ/7SC0v7ag4+VQ3axL5K1OThsJFuZoHV7q2DLEEFwAK5x2X+8DXZWlsLn6lMVSiH474602HOQhfafKlpuWWEKSknh2WY=0z8qjrAfwTcqem0e3SGW3f4OH/lXUDJbHM46bJQE7oOvZntHfMHaobSvNtRuyJPB00oZuRkE1ajZLOpQGkMmZ+sFrvJNqWBhuey/mUaPvbOZ5J4BUlTW8ZlWRIwHYk/voFA238stqXc477xG7TIQBV7Tt3PqxJNLL5NjG7jvAK0=adI6dYJzz+uI4qL8GsiRhSHd3l0yWBUujwurgDC7Bi5suiN15dQA4QyYLxbBSG3OJVN0dNmlKcD/uigYTNj1WWWX7hGEgnh1eh7a7gzAqwPDTFtLKkh2Mxkjr94EyxziphzxkRMCBY1PftXu1PzStmBXBt4Ze05VKhYTvngyZwM=HiK0fUc7vrpmDBh1kOXhqaBzofjwq/dqQysGSGRgHiZYpbjuVPeQkFmFR6UHIZb01EUPMlcvDHzw2fIwNk/jngIpYpf+GP1N9Ejp+JXKnAXdsVHUtc9kwmosbDEqdDn4C+5ogxvW+oJRVGC/0Iqmo0eaQJl1m70CL5p/kCQzsyo=";

		// String decryptedText = decryptText(t, PRIVATE_KEY_FILE_PATH,
		// PASSWORD);
		// System.out.println("decrypted Text:\n\n" + decryptedText);

		String text = "008809040";
		String[] a = { "a" };
		try {
			System.out.println(Sign(PRIVATE_KEY_FILE_PATH, PASSWORD, text, a));			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Encrypt text using public key
	 * 
	 * @param text
	 * @param certFile
	 * @return encrypted string
	 */
	public static Boolean encryptText(String plainText, String certFile,
			String[] outputEncrypt) {
		System.out.println("Signer.encryptText()");
		PublicKey pubKey = null;
		try {
			pubKey = getPublicKey(certFile);
			String inputString = plainText.trim();

			int pubKeyLen = ((RSAPublicKey) pubKey).getModulus().bitLength();
			int keySize = pubKeyLen / 8;// dwKeySize / 8; 128
			int maxLength = keySize - 42; // 86

			byte[] bytes = inputString.getBytes(CHARSET);
			int dataLength = bytes.length;
			// int iterations = dataLength / maxLength;
			double iterations = Math.ceil((double) dataLength / maxLength);
			StringBuffer strBuf = new StringBuffer();
			for (int i = 0; i < iterations; i++) {
				byte[] tempBytes = new byte[(dataLength - maxLength * i > maxLength) ? maxLength
						: dataLength - maxLength * i];
				if (i == iterations - 1) {
					System.arraycopy(bytes, i * maxLength, tempBytes, 0,
							dataLength - maxLength * i);
				} else {
					System.arraycopy(bytes, i * maxLength, tempBytes, 0,
							maxLength);
				}
				byte[] encryptedBytes = encrypt(tempBytes, pubKey);
				encryptedBytes = reverseByte(encryptedBytes);
				byte[] base64EncodeByte = Base64.encodeBase64(encryptedBytes);
				strBuf.append(new String(base64EncodeByte));
			}

			System.out.println("Encrypted Text: \t" + strBuf.toString());
			outputEncrypt[0] = strBuf.toString();
			return Boolean.TRUE;
		} catch (Exception e) {
			if(e.getMessage() != null && !e.getMessage().isEmpty() ) 
				outputEncrypt[0] = e.getMessage();
			else {
				StringWriter errors = new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				outputEncrypt[0] = errors.toString();
			}
			return Boolean.FALSE;
		}
	}

	/**
	 * Perform decrypt text
	 * 
	 * @param encrytedText
	 * @param privKeyPath
	 * @param password
	 * @return decrypted string
	 */
	public static Boolean decryptText(String encrytedText, String privKeyPath,
			String password, String[] outputDecrypt) {
		System.out.println("Signer.decryptText()");
		KeyPair keyPair = getKeyPair(privKeyPath, password);
		PrivateKey privateKey = null;
		try {
			privateKey = keyPair.getPrivate();
			int privKeyLen = ((RSAPrivateKey) privateKey).getModulus()
					.bitLength();

			// Compute block size to decrypt value now 172
			int base64BlockSize = ((privKeyLen / 8) % 3 != 0) ? (((privKeyLen / 8) / 3) * 4) + 4
					: ((privKeyLen / 8) / 3) * 4;
			// int keySize = privKeyLen / 8;
			// int maxLength = keySize - 42;

			int iterations = encrytedText.length() / base64BlockSize;
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

			for (int i = 0; i < iterations; i++) {
				String blockEncrytedText = encrytedText.substring(i
						* base64BlockSize, (i + 1) * base64BlockSize);
				byte[] inBytes = blockEncrytedText.getBytes("UTF-32");
				byte[] base64decodeByte = Base64.decodeBase64(inBytes);
				// Reverse byte after base 64 encode
				base64decodeByte = reverseByte(base64decodeByte);
				byte[] decrytedText = decrypt(base64decodeByte, privateKey);
				outputStream.write(decrytedText);
			}

			byte[] combined = outputStream.toByteArray();
			String ret = new String(combined, CHARSET);
			outputDecrypt[0] = ret;
			return Boolean.TRUE;
		} catch (Exception e) {
			if(e.getMessage() != null && !e.getMessage().isEmpty() ) 
				outputDecrypt[0] = e.getMessage();
			else {
				StringWriter errors = new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				outputDecrypt[0] = errors.toString();
			}
			return Boolean.FALSE;
		}
	}

	/**
	 * Generate KeyPair from private key
	 * 
	 * @param privKeyPath
	 * @param password
	 * @return Keypair
	 */
	public static KeyPair getKeyPair(String privKeyPath, String password) {
		System.out.println("Signer.getKeyPair()");
		try {
//			javax.net.ssl.KeyManagerFactory kmf = javax.net.ssl.KeyManagerFactory
//					.getInstance("IBMX509");
			
			KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
			String keyPath = PRIVATE_KEY_FILE_PATH;
			char[] pwd = PASSWORD.toCharArray();
			if (privKeyPath != null && privKeyPath.length() > 0) {
				keyPath = privKeyPath;
			}
			if (password != null && password.length() > 0) {
				pwd = password.toCharArray();
			}
			FileInputStream fs = new FileInputStream(keyPath);
			KeyStore keystore = KeyStore.getInstance("PKCS12");
			keystore.load(fs, pwd);
			// keystore.load(new FileInputStream(certificate), password);
			kmf.init(keystore, pwd);
			Enumeration<String> aliases = keystore.aliases();
			Key key = null;
			String alias = "";

			while (aliases.hasMoreElements()) {
				alias = aliases.nextElement();
				key = keystore.getKey(alias, pwd);
			}

			if (key instanceof PrivateKey) {
				java.security.cert.Certificate cert = keystore
						.getCertificate(alias);
				PublicKey publicKey = cert.getPublicKey();
				return new KeyPair(publicKey, (PrivateKey) key);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	/**
	 * Obtain public key from certificate
	 * 
	 * @param certfile
	 * @return Public Key
	 */
	public static PublicKey getPublicKey(String certfile) {
		System.out.println("Signer.getPublicKey()");
		FileInputStream cerFile;
		try {
			cerFile = new FileInputStream(certfile);
			CertificateFactory f = CertificateFactory.getInstance("X.509");
			X509Certificate certificate = (X509Certificate) f
					.generateCertificate(cerFile);
			PublicKey pubKey = certificate.getPublicKey();
			return pubKey;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Encrypt the plain text using public key.
	 * 
	 * @param text
	 * @param key
	 * @return encrypted byte array
	 */
	public static byte[] encrypt(byte[] bytes, PublicKey key) {
		byte[] cipherText = null;
		try {
			// get an RSA cipher object and print the provider
			final Cipher cipher = Cipher.getInstance(ALGORITHM, "BC");
			// encrypt the plain text using the public key
			cipher.init(Cipher.ENCRYPT_MODE, key);
			cipherText = cipher.doFinal(bytes);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cipherText;
	}

	/**
	 * Decrypt text using private key.
	 * 
	 * @param text
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public static byte[] decrypt(byte[] bytes, PrivateKey key) throws Exception {
		byte[] dectyptedText = null;
		try {
			final Cipher cipher = Cipher.getInstance(ALGORITHM, "BC");
			// decrypt the text using the private key
			cipher.init(Cipher.DECRYPT_MODE, key);
			dectyptedText = cipher.doFinal(bytes);

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		// return new String(dectyptedText, "UTF-32LE");
		return dectyptedText;
	}

	/**
	 * Reverse byte
	 * 
	 * @param ins
	 * @return
	 */
	public static byte[] reverseByte(byte[] ins) {
		final int n = ins.length;
		int j = 0;
		byte ret[] = new byte[n];
		for (int i = ins.length - 1; i >= 0; i--) {
			ret[j] = ins[i];
			j++;
		}
		return ret;
	}

	/**
	 * Sign Data
	 * 
	 * @param privKeyPath
	 * @param password
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public static Boolean Sign(String privKeyPath, String password,
			String data, String[] outputSignature) {
		System.out.println("Signer.Sign()");
		try {
			KeyPair keyPair = getKeyPair(privKeyPath, password);
			Signature signature = Signature.getInstance("SHA1withRSA", "BC");
			signature.initSign(keyPair.getPrivate(), new SecureRandom());
			byte[] message = data.getBytes();
			signature.update(message);
			byte[] sigBytes = signature.sign();
			// signature.initVerify(keyPair.getPublic());
			// signature.update(message);
			// System.out.println(signature.verify(sigBytes));
			byte[] base64EncodeByte = Base64.encodeBase64(sigBytes);
			outputSignature[0] = new String(base64EncodeByte);
			return Boolean.TRUE;
		} catch (Exception e) {
			if(e.getMessage() != null && !e.getMessage().isEmpty() ) 
				outputSignature[0] = e.getMessage();
			else {
				StringWriter errors = new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				outputSignature[0] = errors.toString();
			}
			return Boolean.FALSE;
		}

	}

	/**
	 * Verify
	 * 
	 * @param recipicentCert
	 * @param data
	 * @param signature
	 * @return
	 */
	public static Boolean Verify(String recipicentCert, String data,
			String signatureText, String[] failure) {
		System.out.println("Signer.Verify()");
		PublicKey pubKey = null;
		pubKey = getPublicKey(recipicentCert);
		try {
			Signature signature = Signature.getInstance("SHA1withRSA", "BC");
			byte[] message = data.getBytes();
			signature.initVerify(pubKey);
			signature.update(message);
			signature.verify(signatureText.getBytes());
			// System.out.println("OK");
			return Boolean.TRUE;
		} catch (Exception e) {
			if(e.getMessage() != null && !e.getMessage().isEmpty() ) 
				failure[0] = e.getMessage();
			else {
				StringWriter errors = new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				failure[0] = errors.toString();
			}
			// System.out.println("Invalid digital signature from partner");
			return Boolean.FALSE;
		}
	}
}
