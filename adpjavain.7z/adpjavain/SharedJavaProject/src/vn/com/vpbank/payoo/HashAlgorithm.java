package vn.com.vpbank.payoo;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class HashAlgorithm {

	private MessageDigest md = null;

	public HashAlgorithm() {
		try {
			md = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String ComputeHash(String passClient) {
		StringBuffer buffer = null;
		StringBuffer hexString = null;
		try {
			buffer = new StringBuffer();
			hexString = new StringBuffer();
			md.update(passClient.getBytes("UTF-8"));
			byte byteData[] = md.digest();
			for (int i = 0; i < byteData.length; i++) {
				buffer.append(Integer
						.toString((byteData[i] & 0xff) + 0x100, 16)
						.substring(1));
			}

			for (int i = 0; i < byteData.length; i++) {
				String hex = Integer.toHexString(0xff & byteData[i]);
				if (hex.length() == 1)
					hexString.append('0');
				hexString.append(hex);
			}
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// System.out.println("Digest(in hex format):: " +
		// hexString.toString());
		return hexString.toString();
	}

}
