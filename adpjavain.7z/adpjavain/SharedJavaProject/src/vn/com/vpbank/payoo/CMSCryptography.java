package vn.com.vpbank.payoo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.Security;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertStore;
import java.security.cert.CertStoreException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.CollectionCertStoreParameters;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Enumeration;

import org.bouncycastle.cms.CMSEnvelopedData;
import org.bouncycastle.cms.CMSEnvelopedDataGenerator;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.CMSSignedDataGenerator;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Base64;

import sun.misc.BASE64Encoder;

public class CMSCryptography {

	static {
		Security.addProvider(new BouncyCastleProvider());
	}
	private X509Certificate signerCertificate = null;
	private PrivateKey signerPrivateKey = null;
	private X509Certificate recipientCertificate = null;
	
	public CMSCryptography(){
		if (Security.getProvider("BC") == null) {
			Security.addProvider(new BouncyCastleProvider());
		}
	}

	public void setSignerCredential(String signerCertPath,
			String signerCertPassword) throws NoSuchAlgorithmException,
			CertificateException, FileNotFoundException, IOException,
			KeyStoreException, UnrecoverableKeyException {
		String aliasName = "";
		// KeyStore keyStore = KeyStore.getInstance("PKCS12", "BC");
		KeyStore keyStore = KeyStore.getInstance("PKCS12");
		keyStore.load(new FileInputStream(signerCertPath),
				signerCertPassword.toCharArray());
		Enumeration<String> listAliases = keyStore.aliases();
		while (listAliases.hasMoreElements()) {
			aliasName = listAliases.nextElement().toString();
		}
		signerCertificate = (X509Certificate) keyStore
				.getCertificate(aliasName);
		signerPrivateKey = (PrivateKey) keyStore.getKey(aliasName,
				signerCertPassword.toCharArray());

		/*
		 * Write private key to pem file
		 */
		// Store Private Key.
		// PKCS8EncodedKeySpec pkcs8EncodedKeySpec = new PKCS8EncodedKeySpec(
		// _PrivateKey.getEncoded());
		// FileOutputStream fos = new FileOutputStream("." + "\\certificates\\"
		// + "private.pem");
		// fos.write(pkcs8EncodedKeySpec.getEncoded());
		// fos.close();
	}

	public void setRecipientPublicCert(String recipientCertPath) throws CertificateException, FileNotFoundException, NoSuchProviderException {
		
		CertificateFactory factory = CertificateFactory.getInstance("X509",
				"BC");
		recipientCertificate = (X509Certificate) factory
				.generateCertificate(new FileInputStream(recipientCertPath));
	}

	public String Sign(byte[] data) throws CertStoreException, NoSuchAlgorithmException, NoSuchProviderException, InvalidAlgorithmParameterException, CMSException, IOException {
		return new BASE64Encoder().encode(ComputeSignature(data,
				true, CMSSignedDataGenerator.DIGEST_SHA1));
	}

	public String SignAndEncrypt(byte[] data) throws NoSuchAlgorithmException, NoSuchProviderException, CertStoreException, InvalidAlgorithmParameterException, CMSException, IOException {
		return Encrypt(ComputeSignature(data, false,
				CMSSignedDataGenerator.ENCRYPTION_DSA));
	}

	public Boolean Verify(byte[] data, String signature) throws CMSException, NoSuchAlgorithmException, NoSuchProviderException {
		CMSProcessableByteArray digestContent = new CMSProcessableByteArray(
				data);
		CMSSignedData Signed = new CMSSignedData(digestContent,
				Base64.decode(signature));
		SignerInformation Signer = (SignerInformation) Signed
				.getSignerInfos().getSigners().iterator().next();
		return Signer.verify(recipientCertificate.getPublicKey(), "BC");
	}

	public String Encrypt(byte[] data) throws NoSuchAlgorithmException, NoSuchProviderException, CMSException, IOException {
		if (Security.getProvider("BC") == null) {
			Security.addProvider(new BouncyCastleProvider());
		}
		CMSEnvelopedDataGenerator env = new CMSEnvelopedDataGenerator();
		env.addKeyTransRecipient(recipientCertificate);
		CMSProcessableByteArray digestContent = new CMSProcessableByteArray(
				data);

		CMSEnvelopedData envData = env.generate(digestContent,
				CMSEnvelopedDataGenerator.DES_EDE3_CBC, "BC");
		return new sun.misc.BASE64Encoder().encode(envData.getEncoded());
	}

	private byte[] ComputeSignature(byte[] data, boolean isDetach,
			String CMSSignedDataGenerator) throws CertStoreException,
			CMSException, NoSuchAlgorithmException, NoSuchProviderException,
			InvalidAlgorithmParameterException, IOException {
		if (Security.getProvider("BC") == null) {
			Security.addProvider(new BouncyCastleProvider());
		}
		CMSSignedDataGenerator Signer = new CMSSignedDataGenerator();
		Signer.addSigner(signerPrivateKey, signerCertificate,
				CMSSignedDataGenerator);
		CMSProcessableByteArray digestContent = new CMSProcessableByteArray(
				data);
		if (!isDetach) {
			ArrayList<Object> listCerts = new ArrayList<Object>();
			listCerts.add(signerCertificate);
			CertStore certStore = CertStore.getInstance("Collection",
					new CollectionCertStoreParameters(listCerts));
			Signer.addCertificatesAndCRLs(certStore);
		}
		CMSSignedData Signed = Signer.generate(digestContent, !isDetach, "BC");
		return Signed.getEncoded();
	}

}
