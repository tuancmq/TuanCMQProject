package vn.com.vpbank.payoo;


public class Signer {
	
	public static Boolean Sign(String signerCert, String password, String data, String[] outputSignature) {
		try {
			CMSCryptography cryp = new CMSCryptography();
			cryp.setSignerCredential(signerCert, password);
			String s = cryp.Sign(data.getBytes("UTF-8"));
			outputSignature[0] = s;
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			outputSignature[0] = e.getMessage();
			return false;
		}
	}

	public static Boolean Verify(String recipicentCert, String password, String data, String signature, String[] failure) {
		failure[0] = null;
		try {
			CMSCryptography cryp = new CMSCryptography();
			cryp.setRecipientPublicCert(recipicentCert);
			if (cryp.Verify(data.getBytes("UTF-8"), signature)){
				return true;
			}
			else{
				failure[0] = "Invalid digital signature from partner";
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			failure[0] = e.getMessage();
			return false;
		}
	}
}
