#! /bin/bash

ANT_HOME=/home/roman/java/apache-ant-1.9.4

if [ -z "$ANT_HOME" ] ; then
  echo 1
  RUN_ANT=ant
else 
  echo 2
  RUN_ANT="$ANT_HOME/bin/ant"
fi

$RUN_ANT run -DtoolkitHome=/opt/IBM/IntegrationToolkit90