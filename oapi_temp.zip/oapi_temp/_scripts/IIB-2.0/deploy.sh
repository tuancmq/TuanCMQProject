#!/bin/bash

IFS=,

# 
# Deploy compiled BAR files into appropriate execution groups
# 
# Neoflex, 2013
#

. ./config.sh

for i in $bar_list
do

    eg_ref=bar_${i}_execGroup
    
	echo "${i}:"
	# echo "create exgroup..."
    # mqsicreateexecutiongroup ${brk_ref} -e ${!eg_ref} -w $timeout
    echo "deploy..."
    mqsideploy ${brk_ref} -e ${!eg_ref} -a ../deploy/${i}*.bar -w $timeout
    echo "tracing off..."
    mqsichangetrace ${brk_ref} -e ${!eg_ref} -n off
    if [ ${!eg_ref} != ${bar_SrvLog_execGroup} ]
	then
    	echo "logging enable..."
    	mqsichangeflowmonitoring ${brk_ref} -e ${!eg_ref} -j -c active
    fi

done